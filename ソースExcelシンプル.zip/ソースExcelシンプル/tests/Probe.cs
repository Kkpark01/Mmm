using System;
using System.IO;
using System.Linq;
using System.Text;
using SimpleSourceExcel;
class Probe {
    static int Main(string[] args) {
        try {
            if(args[0]=="text") { File.WriteAllText(args[2],Engine.ReadCode(args[1],args[3],args.Length>4?int.Parse(args[4]):2,args.Length>5?int.Parse(args[5]):3),new UTF8Encoding(false)); return 0; }
            var r=new Request { Output=args[1],Existing=args[2]=="-"?"":args[2] }; r.Inputs.AddRange(args.Skip(3));
            bool cancel=false;
            Console.WriteLine(Engine.Run(r,(n,s)=> { if(args[0]=="cancel") cancel=true; },()=>cancel)); return 0;
        } catch(Exception ex) { Console.WriteLine(ex.Message); return 1; }
    }
}
