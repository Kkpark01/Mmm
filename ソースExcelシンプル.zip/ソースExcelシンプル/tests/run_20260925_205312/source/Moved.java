class A {
	string s = "日本語";

}
