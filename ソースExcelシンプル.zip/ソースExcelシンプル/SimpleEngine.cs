using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using SourceExcelImporter;

namespace SimpleSourceExcel {
    public sealed class Request {
        public string Existing = "", Output, Encoding = "自動", Extensions = new Options().Extensions;
        public List<string> Inputs = new List<string>();
        public bool Recursive = true;
    }
    public static class Engine {
        static readonly HashSet<string> Excluded = new HashSet<string>(new[] { ".git", "node_modules", "bin", "obj", "target", ".vs", ".idea", ".venv" }, StringComparer.OrdinalIgnoreCase);
        static void Check(Func<bool> cancel) { if (cancel()) throw new OperationCanceledException(); }
        static void Gather(string input, bool recursive, HashSet<string> seen, List<string> files, ref int skipped, Func<bool> cancel) {
            Check(cancel); string path = Path.GetFullPath(input);
            if (!seen.Add(path)) return;
            if (!File.Exists(path) && !Directory.Exists(path)) throw new IOException("見つかりません: " + path);
            if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0) { skipped++; return; }
            if (File.Exists(path)) { files.Add(path); if (files.Count > 100000) throw new IOException("対象が多すぎます。範囲を絞ってください。"); return; }
            foreach (string file in Directory.GetFiles(path).OrderBy(p => p, StringComparer.OrdinalIgnoreCase)) Gather(file, recursive, seen, files, ref skipped, cancel);
            if (recursive) foreach (string dir in Directory.GetDirectories(path).OrderBy(p => p, StringComparer.OrdinalIgnoreCase)) {
                if (Excluded.Contains(Path.GetFileName(dir))) { skipped++; continue; }
                Gather(dir, recursive, seen, files, ref skipped, cancel);
            }
        }
        public static string Run(Request request, Action<int,string> progress, Func<bool> cancel) {
            string output = Path.GetFullPath(request.Output);
            if (!output.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase) || File.Exists(output)) throw new IOException("未使用の .xlsx ファイル名を指定してください。");
            var files = new List<string>(); var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase); int skipped = 0;
            if (request.Inputs.Count == 0) throw new IOException("ファイル・フォルダを選択してください。");
            foreach (string input in request.Inputs) Gather(input, request.Recursive, seen, files, ref skipped, cancel);
            var ext = new HashSet<string>(request.Extensions.Split(new[] { ' ', ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Select(e => "." + e.TrimStart('.')), StringComparer.OrdinalIgnoreCase);
            skipped += files.Count(f => !ext.Contains(Path.GetExtension(f)));
            files = files.Where(f => ext.Contains(Path.GetExtension(f))).ToList();
            if (files.Count == 0) throw new IOException("対象のテキストファイルがありません。拡張子を確認してください。");
            if (files.Count > 500) throw new IOException("1回の追加は500ファイルまでです。");
            string existing = string.IsNullOrWhiteSpace(request.Existing) ? null : Path.GetFullPath(request.Existing);
            string oldHash = existing == null ? null : ChangePlan.FileHash(existing);
            string temporary = output + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try {
                using (var result = new ZipArchive(new FileStream(temporary, FileMode.CreateNew), ZipArchiveMode.Create)) {
                    ZipArchive old = null; XDocument workbook = null, rels = null, types = null;
                    var sheetNames = new List<string>();
                    try {
                        if (existing != null) {
                            // Parse once for format/size validation; no original source ZIP is required.
                            using (var reader = new WorkbookReader(existing)) sheetNames.AddRange(reader.SheetNames());
                            old = new ZipArchive(new FileStream(existing, FileMode.Open, FileAccess.Read, FileShare.Read), ZipArchiveMode.Read);
                            workbook = WorkbookReader.ReadXml(old.GetEntry("xl/workbook.xml")); rels = WorkbookReader.ReadXml(old.GetEntry("xl/_rels/workbook.xml.rels")); types = WorkbookReader.ReadXml(old.GetEntry("[Content_Types].xml"));
                            var replaced = new HashSet<string> { "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "[Content_Types].xml" };
                            foreach (var entry in old.Entries) {
                                Check(cancel); if (replaced.Contains(entry.FullName)) continue;
                                using (var input = entry.Open()) using (var target = result.CreateEntry(entry.FullName, CompressionLevel.Optimal).Open()) input.CopyTo(target);
                            }
                        }
                        if (sheetNames.Count + files.Count > 500) throw new IOException("追加後のシート数が500を超えます。不要なシートを削除してください。");
                        var names = new HashSet<string>(sheetNames, StringComparer.OrdinalIgnoreCase); int serial = 0, done = 0;
                        foreach (string path in files) {
                            Check(cancel); progress((int)(100.0 * done / files.Count), Path.GetFileName(path));
                            if (new FileInfo(path).Length > 5 * 1024 * 1024) throw new IOException("5MBを超えています: " + path);
                            string label, text = Importer.Decode(File.ReadAllBytes(path), request.Encoding, out label); XmlConvert.VerifyXmlChars(text);
                            string[] lines = ChangePlan.Lines(text);
                            if (lines.Length > 1048574 || lines.Any(l => l.Length > 32767)) throw new IOException("Excelの上限を超えています: " + path);
                            string filename = Regex.Replace(Path.GetFileName(path), "[\\[\\]:*?/\\\\'\u0000-\u001f]", "_");
                            string name; do { string prefix = (++serial).ToString("D4") + "_"; name = prefix + filename.Substring(0, Math.Min(31-prefix.Length, filename.Length)); } while (!names.Add(name));
                            Action<XmlWriter> write = x => {
                                Importer.BeginSheet(x, new[] { 12.0, 120.0 }, 2);
                                Importer.Row(x, new[] { "元ファイル", path }, 0, 32);
                                Importer.Row(x, new[] { "行番号", "コード" }, 1);
                                for (int i = 0; i < lines.Length; i++) { if (i % 1000 == 0) Check(cancel); Importer.Row(x, new[] { (i+1).ToString(), lines[i] }, 2); }
                                Importer.EndSheet(x, null);
                            };
                            if (old == null) { sheetNames.Add(name); using (var x = Importer.Writer(result, "xl/worksheets/sheet" + sheetNames.Count + ".xml")) write(x); }
                            else AppendImporter.Register(result, workbook, rels, types, name, new[] { 0, 0, 0 }, write);
                            done++;
                        }
                        if (old == null) Importer.Package(result, sheetNames);
                        else {
                            using (var x = Importer.Writer(result, "xl/workbook.xml")) workbook.Save(x);
                            using (var x = Importer.Writer(result, "xl/_rels/workbook.xml.rels")) rels.Save(x);
                            using (var x = Importer.Writer(result, "[Content_Types].xml")) types.Save(x);
                        }
                    } finally { if (old != null) old.Dispose(); }
                }
                Check(cancel);
                if (existing != null && ChangePlan.FileHash(existing) != oldHash) throw new IOException("追加中に元のExcelが更新されました。保存を待って再実行してください。");
                File.Move(temporary, output); progress(100, "完了");
                return "取込 " + files.Count + "件 / 対象外・除外フォルダ " + skipped + "件\r\n" + output;
            } finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
        public static string[] Sheets(string path) { using (var reader = new WorkbookReader(path)) return reader.SheetNames(); }
        public static string ReadCode(string path, string sheet, int column, int firstRow, int lastRow = 0) {
            if (column < 1 || column > 16384 || firstRow < 1 || firstRow > 1048576 || (lastRow != 0 && lastRow < firstRow)) throw new IOException("列・行の指定を確認してください。");
            using (var reader = new WorkbookReader(path)) {
                var rows = reader.Read(sheet);
                if (lastRow == 0) lastRow = rows.Where(r => r.Key >= firstRow && (WorkbookReader.Get(r.Value, column).Value != "" || WorkbookReader.Get(r.Value, column).Formula || WorkbookReader.Get(r.Value, 1).Value != "")).Select(r => r.Key).DefaultIfEmpty(firstRow-1).Max();
                if (lastRow > 1048576) throw new IOException("行数が大きすぎます。");
                var lines = new List<string>();
                for (int row = firstRow; row <= lastRow; row++) {
                    Dictionary<int,SheetCell> cells; SheetCell cell = rows.TryGetValue(row, out cells) ? WorkbookReader.Get(cells, column) : new SheetCell();
                    if (cell.Formula || cell.Type == "e") throw new IOException(row + "行目に数式・エラーがあります。コードを文字列に直してください。");
                    if (cell.Value != "" && cell.Type != "inlineStr" && cell.Type != "s" && cell.Type != "str") throw new IOException(row + "行目が数値等に変換されています。文字列として入力してください。");
                    lines.Add(Regex.Replace(cell.Value, "\r\n|\r|\n", "\r\n"));
                }
                return string.Join("\r\n", lines);
            }
        }
    }
}
