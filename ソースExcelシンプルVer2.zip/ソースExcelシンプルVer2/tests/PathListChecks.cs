using System;
using System.IO;
using System.Linq;
using SimpleSourceExcel;
class PathListChecks {
    static void Require(bool condition,string message) { if(!condition) throw new Exception(message); }
    static void Main(string[] args) {
        string root=Path.GetFullPath(args[0]); Directory.CreateDirectory(root);
        string folder=Path.Combine(root,"日本語 空白フォルダ"); Directory.CreateDirectory(folder);
        string file=Path.Combine(folder,"引用符テスト.java"); File.WriteAllText(file,"String s = \"text\";");
        string other=Path.Combine(root,"Other.txt"); File.WriteAllText(other,"data");
        var result=PathList.Parse("\uFEFF"+file+"\r\n\r\n\""+folder+"\"\n"+file.ToUpperInvariant()+"\n"+folder+"\\\n"+other+"\n"+Path.Combine(root,"missing.txt")+"\nrelative.java\nC:relative.java\ndir \"C:\\x\" /S /B\n",new[] { other });
        Require(result.Paths.SequenceEqual(new[] { file,folder }),"valid file/folder list");
        Require(result.Duplicates==3,"duplicates within list and existing selections");
        Require(result.Errors.Count==4,"invalid/missing/command lines");
        Require(result.Errors[0].StartsWith("7行目:"),"error line numbering");
        Require(PathList.Parse("\n```text\n"+file+"\n```\n",new string[0]).Paths.Single()==file,"code fence and blank lines");
        Require(PathList.Parse("",new string[0]).Paths.Count==0,"empty list");
        Require(PathList.Parse(string.Join("\n",Enumerable.Repeat(file,1000)),new string[0]).Duplicates==999,"bulk list deduplication");
        Require(PathList.Parse(Path.Combine(root,"*.java"),new string[0]).Errors.Count==1,"wildcard not expanded");
        bool rejected=false; try { PathList.Parse(new string('\n',20001),new string[0]); } catch(IOException) { rejected=true; }
        Require(rejected,"oversized paste rejected");
        var request=new Request { Output=Path.Combine(root,"pasted.xlsx") }; request.Inputs.AddRange(result.Paths);
        Engine.Run(request,(n,s)=>{},()=>false);
        Require(Engine.Sheets(request.Output).Length==1,"folder/file overlapping selection imported once");
        Require(Engine.ReadCode(request.Output,Engine.Sheets(request.Output)[0],2,3)=="String s = \"text\";","pasted list to workbook to code roundtrip");
        Console.WriteLine("PASS: full paths, Japanese/spaces, quotes, BOM, CRLF/LF, file/folder mix, deduplication, missing paths, relative paths/commands/wildcards rejected, 1000 lines, size limit, Excel roundtrip");
    }
}
