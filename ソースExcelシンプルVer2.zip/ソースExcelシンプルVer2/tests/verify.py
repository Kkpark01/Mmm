from pathlib import Path
import subprocess, time, zipfile, json
import openpyxl

app=Path(__file__).resolve().parents[1]
run=app/'tests'/('run_'+time.strftime('%Y%m%d_%H%M%S'))
src=run/'source'
(src/'nested').mkdir(parents=True)
original='class A {\r\n\tstring s = "日本語";\r\n\r\n}\r\n'
(src/'Same.java').write_bytes(original.encode('utf-8'))
(src/'nested'/'Same.java').write_bytes("'CP932 日本語\r\nDim s = \"hello\"\r\n".encode('cp932'))
(src/'empty.txt').write_bytes(b'')
(src/'picture.png').write_bytes(b'ignored')
(src/'node_modules').mkdir()
(src/'node_modules'/'skip.js').write_text('ignored')

def call(args,ok=True):
    result=subprocess.run([str(app/'Probe.exe')]+list(map(str,args)),capture_output=True,timeout=45)
    assert result.returncode==(0 if ok else 1),(result.stdout,result.stderr)
    assert not list(run.glob('*.tmp'))

book=run/'new.xlsx'
call(['run',book,'-',src,src/'Same.java'])
assert not list(run.glob('*.sources.zip'))
b=openpyxl.load_workbook(book)
assert len(b.sheetnames)==3
sheet=next(s for s in b if s['B1'].value==str(src/'Same.java'))
name=sheet.title
assert [r[1] or '' for r in list(sheet.values)[2:]]==original.split('\r\n')
assert all(c.data_type!='f' for row in sheet for c in row)
out=run/'code.txt'
call(['text',book,out,name])
assert out.read_bytes()==original.encode('utf-8')

# Delete every imported sheet except one, rename it, edit code, add custom notes.
for s in list(b):
    if s.title!=name: b.remove(s)
b[name].title='自由なシート名'
b['自由なシート名']['B4']='\tstring s = "edited";'
notes=b.create_sheet('参考')
notes['A1']='=SUM(1,2)'
notes['B2']='残しておく資料'
b.save(book)
before=book.read_bytes()
# Existing source files need not exist: no baseline or source hash dependencies.
(src/'Same.java').rename(src/'Moved.java')
extra=run/'extra'
extra.mkdir()
(extra/'Same.java').write_text('new code\n',encoding='utf-8')
added=run/'added.xlsx'
call(['run',added,book,extra,src/'nested'/'Same.java'])
assert book.read_bytes()==before
with zipfile.ZipFile(book) as old,zipfile.ZipFile(added) as new:
    for n in old.namelist():
        if n.startswith('xl/worksheets/') or n=='xl/styles.xml': assert old.read(n)==new.read(n),n
a=openpyxl.load_workbook(added)
assert len(a.sheetnames)==4
assert a['自由なシート名']['B4'].value=='\tstring s = "edited";'
assert a['参考']['A1'].value=='=SUM(1,2)'
# Repeat append of same file creates separate sheet; edited code is never replaced.
again=run/'again.xlsx'
call(['run',again,added,extra/'Same.java'])
assert len(openpyxl.load_workbook(again).sheetnames)==5
# Multiline code in a single Excel cell must not gain CSV quoting.
q=openpyxl.Workbook()
q.active.title='引用符確認'
q.active['A1']='行番号'
q.active['B1']='コード'
q.active['A2']='1'
q.active['B2']='Console.WriteLine("a");\nConsole.WriteLine("b");'
q.active['A3']='2'
q.active['B3']='=not_a_formula'
q.active['B3'].data_type='s'
q.active['A4']='3'
q.active['B4']='\t  trailing  '
q.active['A5']='4'
qfile=run/'quotes.xlsx'
q.save(qfile)
call(['text',qfile,run/'quotes.txt','引用符確認',2,2])
assert (run/'quotes.txt').read_bytes()==b'Console.WriteLine("a");\r\nConsole.WriteLine("b");\r\n=not_a_formula\r\n\t  trailing  \r\n'
q.active['B3']='=1+1'
q.save(qfile)
call(['text',qfile,run/'formula.txt','引用符確認',2,2],False)
q.active['B3']=123
q.save(qfile)
call(['text',qfile,run/'number.txt','引用符確認',2,2],False)
assert not (run/'formula.txt').exists() and not (run/'number.txt').exists()
# Cancellation, invalid text, missing source and output collision keep prior data.
call(['cancel',run/'cancel.xlsx',added,extra],False)
assert not (run/'cancel.xlsx').exists()
(extra/'bad.txt').write_bytes(b'bad\0text')
call(['run',run/'bad.xlsx',added,extra],False)
assert not (run/'bad.xlsx').exists()
call(['run',run/'missing.xlsx','-',run/'missing'],False)
call(['run',book,'-',extra],False)
assert book.read_bytes()==before
assert subprocess.run([str(app/'SourceExcelSimple_v2.exe'),'--preview',str(run/'app.png')],timeout=30).returncode==0
report={'result':'PASS','checks':['files and recursive folders together','overlapping selections deduplicated','same names','UTF8 and CP932','no ZIP or mandatory sheets','delete/rename/edit sheets then append','preserve old worksheet and style XML bytes','append without original sources','repeated append','plain text without CSV quotation','multiline cell/quotes/tabs/blank lines/trailing whitespace','formula and number refusal','cancel/error cleanup','old output not overwritten']}
(run/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report))
print(run)
