$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework/v4.0.30319/csc.exe' }
Push-Location -LiteralPath $PSScriptRoot
try {
    $shared = '..\ソースExcel取込'
    & $compiler /nologo /target:winexe /main:SimpleSourceExcel.SimpleProgram /optimize+ /out:SourceExcelSimple_v2.exe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll /reference:System.Xml.Linq.dll SimpleEngine.cs SimpleApp.cs PathList.cs "$shared\SourceImporter.cs" "$shared\WorkbookWorkflow.cs" "$shared\AppendImporter.cs" "$shared\ReviewForm.cs"
    if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
} finally { Pop-Location }
