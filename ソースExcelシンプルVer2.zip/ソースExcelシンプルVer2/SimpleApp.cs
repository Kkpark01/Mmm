using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimpleSourceExcel {
    sealed class InputPicker : Form {
        readonly TextBox location = new TextBox();
        readonly ListView entries = new ListView();
        public string[] Paths = new string[0];
        public InputPicker(string initial = null) {
            Text = "ファイル・フォルダをCtrlで複数選択"; Size = new Size(850, 650); MinimumSize = new Size(650,450); StartPosition = FormStartPosition.CenterParent;
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(12), RowCount = 3, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,40)); layout.RowStyles.Add(new RowStyle(SizeType.Percent,100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute,45)); Controls.Add(layout);
            var bar = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3 }; bar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,80)); bar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); bar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,70));
            var up = new Button { Text = "上へ", Dock = DockStyle.Fill }; var go = new Button { Text = "移動", Dock = DockStyle.Fill }; location.Dock = DockStyle.Fill;
            bar.Controls.Add(up,0,0); bar.Controls.Add(location,1,0); bar.Controls.Add(go,2,0); layout.Controls.Add(bar,0,0);
            entries.Dock = DockStyle.Fill; entries.View = View.Details; entries.FullRowSelect = true; entries.MultiSelect = true; entries.HideSelection = false;
            entries.Columns.Add("名前",560); entries.Columns.Add("種類",140); layout.Controls.Add(entries,0,1);
            var actions = new FlowLayoutPanel { Dock = DockStyle.Fill }; var choose = new Button { Text = "選択した項目を追加", Width = 180, Height = 34 }; var current = new Button { Text = "表示中のフォルダを追加", Width = 210, Height = 34 };
            actions.Controls.Add(choose); actions.Controls.Add(current); layout.Controls.Add(actions,0,2);
            go.Click += delegate { Navigate(location.Text); };
            location.KeyDown += delegate(object sender, KeyEventArgs e) { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Navigate(location.Text); } };
            up.Click += delegate { try { var parent = Directory.GetParent(location.Text); if (parent != null) Navigate(parent.FullName); } catch (Exception ex) { MessageBox.Show(this, ex.Message); } };
            entries.DoubleClick += delegate { if (entries.SelectedItems.Count == 1 && Directory.Exists((string)entries.SelectedItems[0].Tag)) Navigate((string)entries.SelectedItems[0].Tag); };
            choose.Click += delegate { if (entries.SelectedItems.Count == 0) return; Paths = entries.SelectedItems.Cast<ListViewItem>().Select(i => (string)i.Tag).ToArray(); DialogResult = DialogResult.OK; };
            current.Click += delegate { if (Directory.Exists(location.Text)) { Paths = new[] { Path.GetFullPath(location.Text) }; DialogResult = DialogResult.OK; } };
            Navigate(initial ?? Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
        }
        void Navigate(string path) {
            try {
                var root = Path.GetFullPath(path); var dirs = Directory.GetDirectories(root).OrderBy(p=>p).ToArray(); var files = Directory.GetFiles(root).OrderBy(p=>p).ToArray();
                entries.BeginUpdate(); entries.Items.Clear();
                foreach (string p in dirs.Concat(files)) { var item = new ListViewItem(new[] { Path.GetFileName(p), Directory.Exists(p) ? "フォルダ" : "ファイル" }); item.Tag = p; entries.Items.Add(item); }
                entries.EndUpdate(); location.Text = root;
            } catch (Exception ex) { entries.EndUpdate(); MessageBox.Show(this, ex.Message, "移動できません"); }
        }
    }
    sealed class CodeForm : Form {
        readonly ComboBox sheets = new ComboBox();
        readonly NumericUpDown column = new NumericUpDown { Minimum=1, Maximum=16384, Value=2, Width=70 }, first = new NumericUpDown { Minimum=1, Maximum=1048576, Value=3, Width=70 }, last = new NumericUpDown { Minimum=0, Maximum=1048576, Value=0, Width=80 };
        readonly TextBox preview = new TextBox { Multiline=true, ScrollBars=ScrollBars.Both, WordWrap=false, ReadOnly=true, Dock=DockStyle.Fill, Font=new Font("Consolas",11) };
        readonly Label status = new Label { Dock=DockStyle.Fill };
        readonly string path;
        string current;
        public CodeForm(string workbook) {
            path = workbook; Text="コードをプレーンテキストで取り出す"; Size=new Size(1000,700); MinimumSize=new Size(850,500); StartPosition=FormStartPosition.CenterParent;
            var layout=new TableLayoutPanel { Dock=DockStyle.Fill, Padding=new Padding(15), ColumnCount=1, RowCount=4 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,45)); layout.RowStyles.Add(new RowStyle(SizeType.Percent,100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute,45)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute,50)); Controls.Add(layout);
            var fields=new FlowLayoutPanel { Dock=DockStyle.Fill };
            sheets.DropDownStyle=ComboBoxStyle.DropDownList; sheets.Width=290; sheets.Items.AddRange(Engine.Sheets(path));
            fields.Controls.Add(sheets); fields.Controls.Add(new Label { Text="コード列番号", AutoSize=true }); fields.Controls.Add(column); fields.Controls.Add(new Label { Text="開始行", AutoSize=true }); fields.Controls.Add(first); fields.Controls.Add(new Label { Text="終了行(0=自動)", AutoSize=true }); fields.Controls.Add(last);
            layout.Controls.Add(fields,0,0); layout.Controls.Add(preview,0,1);
            var buttons=new FlowLayoutPanel { Dock=DockStyle.Fill }; var refresh=new Button { Text="読み直す", Width=110, Height=34 }; var copy=new Button { Text="プレーンテキストでコピー", Width=230, Height=34 }; var save=new Button { Text="テキスト保存…", Width=140, Height=34 };
            buttons.Controls.Add(refresh); buttons.Controls.Add(copy); buttons.Controls.Add(save); layout.Controls.Add(buttons,0,2); layout.Controls.Add(status,0,3);
            sheets.SelectedIndexChanged+=delegate { Reload(); }; column.ValueChanged+=delegate { current=null; }; first.ValueChanged+=delegate { current=null; }; last.ValueChanged+=delegate { current=null; };
            refresh.Click+=delegate { Reload(); };
            copy.Click+=delegate { if (!Reload()) return; try { if (current.Length==0) { status.Text="コードが空です。コピーは変更していません。"; return; } Clipboard.SetText(current,TextDataFormat.UnicodeText); status.Text="コピーしました。VS Codeに貼り付けてください。コード本来の引用符は保持しています。"; } catch(Exception ex) { MessageBox.Show(this,ex.Message); } };
            save.Click+=delegate { if (!Reload()) return; using(var d=new SaveFileDialog { Filter="テキスト|*.txt|すべてのファイル|*.*", FileName=(string)sheets.SelectedItem+".txt" }) { if(d.ShowDialog(this)==DialogResult.OK) try { File.WriteAllText(d.FileName,current,new UTF8Encoding(false)); status.Text="UTF-8で保存しました: "+d.FileName; } catch(Exception ex) { MessageBox.Show(this,ex.Message,"保存できません"); } } };
            if(sheets.Items.Count>0) sheets.SelectedIndex=0;
        }
        bool Reload() {
            try { if(sheets.SelectedItem==null) return false; current=Engine.ReadCode(path,(string)sheets.SelectedItem,(int)column.Value,(int)first.Value,(int)last.Value); preview.Text=current; status.Text="余分な囲み引用符を付けずにコピーします。改行はCRLFです。"; return true; }
            catch(Exception ex) { current=null; preview.Clear(); status.Text=ex.Message; return false; }
        }
    }
    public sealed class SimpleForm : Form {
        readonly ListBox inputs=new ListBox { Dock=DockStyle.Fill, SelectionMode=SelectionMode.MultiExtended, HorizontalScrollbar=true, AllowDrop=true };
        readonly TextBox existing=new TextBox { Dock=DockStyle.Fill }, extensions=new TextBox { Dock=DockStyle.Fill, Text=new Request().Extensions, Multiline=true, ScrollBars=ScrollBars.Vertical };
        readonly ComboBox encoding=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList, Width=140 };
        readonly CheckBox recursive=new CheckBox { Text="サブフォルダも対象", Checked=true, AutoSize=true };
        readonly Label status=new Label { Dock=DockStyle.Fill, AutoEllipsis=true };
        readonly ProgressBar progress=new ProgressBar { Dock=DockStyle.Fill };
        readonly BackgroundWorker worker=new BackgroundWorker { WorkerReportsProgress=true, WorkerSupportsCancellation=true };
        public SimpleForm() {
            Text="ソースExcel シンプル版 ver2"; ClientSize=new Size(960,680); MinimumSize=new Size(940,690); Font=new Font("Yu Gothic UI",10); StartPosition=FormStartPosition.CenterScreen;
            var grid=new TableLayoutPanel { Dock=DockStyle.Fill, Padding=new Padding(20), ColumnCount=1, RowCount=9 }; Controls.Add(grid);
            foreach(int height in new[] { 40,44,210,42,70,65,48,25,80 }) grid.RowStyles.Add(new RowStyle(SizeType.Absolute,height));
            grid.Controls.Add(new Label { Text="選んでExcelへ。続きはCopilotで。", Font=new Font(Font.FontFamily,17,FontStyle.Bold), Dock=DockStyle.Fill },0,0);
            var select=new FlowLayoutPanel { Dock=DockStyle.Fill }; var pick=new Button { Text="ファイル・フォルダを選択…", Width=235, Height=35 }; var remove=new Button { Text="選択項目を外す", Width=140, Height=35 };
            var paste=new Button { Text="パス一覧を貼り付け…", Width=190, Height=35 };
            select.Controls.Add(pick); select.Controls.Add(remove); select.Controls.Add(paste); grid.Controls.Add(select,0,1); grid.Controls.Add(inputs,0,2);
            var opts=new FlowLayoutPanel { Dock=DockStyle.Fill }; opts.Controls.Add(recursive); opts.Controls.Add(new Label { Text="文字コード",AutoSize=true }); encoding.Items.AddRange(new object[] { "自動","UTF-8","CP932" }); encoding.SelectedIndex=0; opts.Controls.Add(encoding); grid.Controls.Add(opts,0,3);
            var ext=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=2 }; ext.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,100)); ext.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); ext.Controls.Add(new Label { Text="対象拡張子",AutoSize=true },0,0); ext.Controls.Add(extensions,1,0); grid.Controls.Add(ext,0,4);
            var basebar=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=3,RowCount=2 }; basebar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); basebar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,145)); basebar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,125)); basebar.Controls.Add(new Label { Text="追加先Excel（空欄なら新規作成）",AutoSize=true },0,0); basebar.Controls.Add(existing,0,1);
            var choose=new Button { Text="既存Excelを選択…",Dock=DockStyle.Fill }; var clear=new Button { Text="新規に戻す",Dock=DockStyle.Fill }; basebar.Controls.Add(choose,1,1); basebar.Controls.Add(clear,2,1); grid.Controls.Add(basebar,0,5);
            var actions=new FlowLayoutPanel { Dock=DockStyle.Fill }; var run=new Button { Text="Excelを作成・追加…",Width=200,Height=36 }; var cancel=new Button { Text="中止",Width=90,Height=36,Enabled=false }; var code=new Button { Text="コードを文字列でコピー…",Width=240,Height=36 }; actions.Controls.Add(run); actions.Controls.Add(cancel); actions.Controls.Add(code); grid.Controls.Add(actions,0,6); grid.Controls.Add(progress,0,7); grid.Controls.Add(status,0,8);
            status.Text="コードシートだけを作成します。不要シートはExcelで削除できます。追加時は別名保存します。";
            pick.Click+=delegate { using(var dialog=new InputPicker()) if(dialog.ShowDialog(this)==DialogResult.OK) AddPaths(dialog.Paths); };
            paste.Click+=delegate { using(var dialog=new PathListForm(inputs.Items.Cast<string>().ToArray())) if(dialog.ShowDialog(this)==DialogResult.OK) { AddPaths(dialog.Paths); status.Text="パス一覧から登録しました。選択中: "+inputs.Items.Count+"件。対象拡張子を確認してExcelを作成してください。"; } };
            remove.Click+=delegate { foreach(var item in inputs.SelectedItems.Cast<object>().ToArray()) inputs.Items.Remove(item); };
            inputs.DragEnter+=delegate(object s,DragEventArgs e) { if(e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect=DragDropEffects.Copy; };
            inputs.DragDrop+=delegate(object s,DragEventArgs e) { AddPaths((string[])e.Data.GetData(DataFormats.FileDrop)); };
            choose.Click+=delegate { using(var d=new OpenFileDialog { Filter="Excel|*.xlsx" }) if(d.ShowDialog(this)==DialogResult.OK) existing.Text=d.FileName; };
            clear.Click+=delegate { existing.Clear(); };
            code.Click+=delegate { using(var d=new OpenFileDialog { Filter="Excel|*.xlsx",Title="編集後に保存したExcelを選択" }) if(d.ShowDialog(this)==DialogResult.OK) try { using(var dialog=new CodeForm(d.FileName)) dialog.ShowDialog(this); } catch(Exception ex) { MessageBox.Show(this,ex.Message); } };
            Action<bool> busy=value=> { select.Enabled=!value; inputs.Enabled=!value; opts.Enabled=!value; ext.Enabled=!value; basebar.Enabled=!value; run.Enabled=!value; code.Enabled=!value; cancel.Enabled=value; };
            run.Click+=delegate {
                if(inputs.Items.Count==0) { MessageBox.Show(this,"ファイル・フォルダを選んでください。"); return; }
                using(var d=new SaveFileDialog { Filter="Excel|*.xlsx", FileName="ソース_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".xlsx" }) {
                    if(d.ShowDialog(this)!=DialogResult.OK) return;
                    var r=new Request { Existing=existing.Text.Trim(),Output=d.FileName,Extensions=extensions.Text,Encoding=(string)encoding.SelectedItem,Recursive=recursive.Checked }; r.Inputs.AddRange(inputs.Items.Cast<string>()); busy(true); progress.Value=0; worker.RunWorkerAsync(r);
                }
            };
            worker.DoWork+=delegate(object s,DoWorkEventArgs e) { try { e.Result=Engine.Run((Request)e.Argument,(n,t)=>worker.ReportProgress(n,t),()=>worker.CancellationPending); } catch(OperationCanceledException) { e.Cancel=true; } };
            worker.ProgressChanged+=delegate(object s,ProgressChangedEventArgs e) { progress.Value=e.ProgressPercentage; status.Text=(string)e.UserState; };
            worker.RunWorkerCompleted+=delegate(object s,RunWorkerCompletedEventArgs e) { busy(false); status.Text=e.Cancelled?"中止しました。元のExcelは変更していません。":e.Error!=null?"エラー: "+e.Error.Message:(string)e.Result; };
            cancel.Click+=delegate { worker.CancelAsync(); cancel.Enabled=false; };
            FormClosing+=delegate(object s,FormClosingEventArgs e) { if(worker.IsBusy) { e.Cancel=true; worker.CancelAsync(); status.Text="中止後に閉じてください。"; } };
        }
        void AddPaths(string[] paths) { foreach(string path in paths) if(!inputs.Items.Cast<string>().Any(p=>string.Equals(p,path,StringComparison.OrdinalIgnoreCase))) inputs.Items.Add(path); }
    }
    public static class SimpleProgram {
        static void Prepare(Control c) { var handle=c.Handle; foreach(Control child in c.Controls) Prepare(child); c.PerformLayout(); }
        [STAThread] public static void Main(string[] args) {
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            using(Form form=args.Length==3 && args[0]=="--preview-picker" ? (Form)new InputPicker(args[1]) : args.Length==3 && args[0]=="--preview-code" ? (Form)new CodeForm(args[1]) : new SimpleForm()) {
                if((args.Length==2 && args[0]=="--preview") || (args.Length==3 && (args[0]=="--preview-picker" || args[0]=="--preview-code"))) { Prepare(form); using(var image=new Bitmap(form.Width,form.Height)) { form.DrawToBitmap(image,new Rectangle(0,0,form.Width,form.Height)); image.Save(args[args.Length-1]); } return; }
                Application.Run(form);
            }
        }
    }
}
