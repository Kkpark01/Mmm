using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SimpleSourceExcel {
    public sealed class PathListResult {
        public readonly List<string> Paths = new List<string>();
        public readonly List<string> Errors = new List<string>();
        public int Duplicates;
        public string Summary { get { return "追加可能 " + Paths.Count + "件 / 重複 " + Duplicates + "件 / 登録不可 " + Errors.Count + "件"; } }
    }
    public static class PathList {
        static string Key(string path) { return Path.GetFullPath(path).TrimEnd('\\', '/'); }
        public static PathListResult Parse(string text, IEnumerable<string> existing) {
            var result = new PathListResult();
            var seen = new HashSet<string>(existing.Select(Key), StringComparer.OrdinalIgnoreCase);
            string[] lines = Regex.Split(text ?? "", "\r\n|\r|\n");
            if (lines.Length > 20000) throw new IOException("1回に貼り付けられるのは20,000行までです。分けて追加してください。");
            for (int i = 0; i < lines.Length; i++) {
                string path = lines[i].Trim().TrimStart('\uFEFF');
                if (path.Length == 0 || path.StartsWith("```")) continue;
                if (path.Length >= 2 && path[0] == '"' && path[path.Length-1] == '"') path = path.Substring(1, path.Length-2);
                try {
                    if (!Regex.IsMatch(path, "^[a-zA-Z]:[\\\\/]") && !path.StartsWith("\\\\")) throw new IOException("フルパスを指定してください");
                    if (path.IndexOfAny(new[] { '*', '?', '"', '\0', '\t' }) >= 0) throw new IOException("パスに使用できない文字が含まれています");
                    path = Path.GetFullPath(path);
                    if (!File.Exists(path) && !Directory.Exists(path)) throw new IOException("見つからないか、アクセスできません");
                    if (!seen.Add(Key(path))) { result.Duplicates++; continue; }
                    result.Paths.Add(path);
                } catch (Exception ex) {
                    if (!(ex is IOException || ex is ArgumentException || ex is UnauthorizedAccessException || ex is NotSupportedException || ex is System.Security.SecurityException)) throw;
                    result.Errors.Add((i+1) + "行目: " + ex.Message + "\r\n" + lines[i]);
                }
            }
            return result;
        }
    }
    sealed class PathListForm : Form {
        readonly TextBox input = new TextBox { Multiline=true, AcceptsReturn=true, AcceptsTab=true, ScrollBars=ScrollBars.Both, WordWrap=false, Dock=DockStyle.Fill, MaxLength=4000000 };
        readonly TextBox report = new TextBox { Multiline=true, ReadOnly=true, ScrollBars=ScrollBars.Both, WordWrap=false, Dock=DockStyle.Fill };
        readonly Label summary = new Label { Dock=DockStyle.Fill };
        readonly Button inspect = new Button { Text="一覧を確認", Width=130, Height=34 }, add = new Button { Text="追加可能な項目を登録", Width=210, Height=34, Enabled=false };
        readonly BackgroundWorker worker = new BackgroundWorker();
        PathListResult result;
        public string[] Paths = new string[0];
        public PathListForm(string[] existing) {
            Text="パス一覧を貼り付けて追加"; Size=new Size(950,700); MinimumSize=new Size(750,550); Font=new Font("Yu Gothic UI",10); StartPosition=FormStartPosition.CenterParent;
            var layout=new TableLayoutPanel { Dock=DockStyle.Fill, Padding=new Padding(15), ColumnCount=1, RowCount=5 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,50)); layout.RowStyles.Add(new RowStyle(SizeType.Percent,65)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute,44)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute,28)); layout.RowStyles.Add(new RowStyle(SizeType.Percent,35)); Controls.Add(layout);
            layout.Controls.Add(new Label { Text="ファイル一覧.txtの中身をCtrl+Vで貼り付けてください（1行1フルパス）。\r\nファイル・フォルダ混在可。登録後、対象拡張子などの通常の取り込み条件が適用されます。", Dock=DockStyle.Fill },0,0);
            layout.Controls.Add(input,0,1); var actions=new FlowLayoutPanel { Dock=DockStyle.Fill }; actions.Controls.Add(inspect); actions.Controls.Add(add); layout.Controls.Add(actions,0,2); layout.Controls.Add(summary,0,3); layout.Controls.Add(report,0,4);
            input.TextChanged+=delegate { result=null; add.Enabled=false; summary.Text="貼り付けたら「一覧を確認」を押してください。"; report.Clear(); };
            inspect.Click+=delegate { input.Enabled=false; inspect.Enabled=false; add.Enabled=false; summary.Text="パスの存在を確認しています…"; worker.RunWorkerAsync(input.Text); };
            worker.DoWork+=delegate(object s,DoWorkEventArgs e) { e.Result=PathList.Parse((string)e.Argument,existing); };
            worker.RunWorkerCompleted+=delegate(object s,RunWorkerCompletedEventArgs e) {
                if(IsDisposed) return;
                input.Enabled=true; inspect.Enabled=true;
                if(e.Error!=null) { summary.Text=e.Error.Message; return; }
                result=(PathListResult)e.Result; summary.Text=result.Summary;
                report.Text=result.Errors.Count==0?"登録不可のパスはありません。":"次の項目は登録しません。内容を確認してください。\r\n\r\n"+string.Join("\r\n\r\n",result.Errors);
                add.Enabled=result.Paths.Count>0;
            };
            add.Click+=delegate { if(result==null) return; Paths=result.Paths.ToArray(); DialogResult=DialogResult.OK; };
        }
    }
}
