using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml;

namespace SourceExcelImporter {
    public class Options {
        public List<string> Folders = new List<string>();
        public string Output, Keyword = "", EncodingName = "自動";
        public bool Recursive = true;
        public string Extensions = ".vb .frm .bas .cls .java .html .htm .js .ts .tsx .jsx .css .scss .sql .xml .json .properties .yml .yaml .md .txt .config .cs .jsp .vue";
    }
    public class Record {
        public string Root, Path, Sheet = "", Encoding = "", Hash = "", Status, Note = "";
        public int Lines;
    }
    public static class Importer {
        const string Ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        static readonly HashSet<string> Excluded = new HashSet<string>(new[] { ".git", "node_modules", "target", "bin", "obj", ".vs", ".idea", ".venv" }, StringComparer.OrdinalIgnoreCase);
        static void Check(Func<bool> cancel) { if (cancel()) throw new OperationCanceledException(); }
        static void Scan(string dir, string root, Options options, List<Record> records, HashSet<string> seen, Func<bool> cancel) {
            Check(cancel);
            foreach (string path in Directory.GetFiles(dir).OrderBy(p => p, StringComparer.OrdinalIgnoreCase)) {
                Check(cancel);
                if (records.Count >= 100000) throw new IOException("対象が10万件を超えます。フォルダを絞ってください。");
                if (seen.Add(path)) records.Add(new Record { Root = root, Path = path });
            }
            if (!options.Recursive) return;
            foreach (string child in Directory.GetDirectories(dir).OrderBy(p => p, StringComparer.OrdinalIgnoreCase)) {
                Check(cancel);
                if (Excluded.Contains(System.IO.Path.GetFileName(child)) || (File.GetAttributes(child) & FileAttributes.ReparsePoint) != 0) {
                    records.Add(new Record { Root = root, Path = child, Status = "除外", Note = "除外フォルダまたはリンク（配下は未走査）" });
                } else Scan(child, root, options, records, seen, cancel);
            }
        }
        internal static string Decode(byte[] bytes, string requested, out string label) {
            Encoding enc;
            int offset = 0;
            if (bytes.Length >= 4 && ((bytes[0] == 255 && bytes[1] == 254 && bytes[2] == 0 && bytes[3] == 0) || (bytes[0] == 0 && bytes[1] == 0 && bytes[2] == 254 && bytes[3] == 255))) {
                bool be = bytes[0] == 0; enc = new UTF32Encoding(be, false, true); label = be ? "UTF-32 BE BOM" : "UTF-32 LE BOM"; offset = 4;
            } else if (bytes.Length >= 3 && bytes[0] == 239 && bytes[1] == 187 && bytes[2] == 191) {
                enc = new UTF8Encoding(false, true); label = "UTF-8 BOM"; offset = 3;
            } else if (bytes.Length >= 2 && bytes[0] == 255 && bytes[1] == 254) {
                enc = new UnicodeEncoding(false, false, true); label = "UTF-16 LE BOM"; offset = 2;
            } else if (bytes.Length >= 2 && bytes[0] == 254 && bytes[1] == 255) {
                enc = new UnicodeEncoding(true, false, true); label = "UTF-16 BE BOM"; offset = 2;
            } else if (requested == "自動") {
                try { label = "UTF-8（自動）"; return new UTF8Encoding(false, true).GetString(bytes); }
                catch (DecoderFallbackException) { label = "CP932（自動・要目視確認）"; return Encoding.GetEncoding(932, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback).GetString(bytes); }
            } else {
                bool sjis = requested == "CP932";
                enc = sjis ? Encoding.GetEncoding(932, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback) : new UTF8Encoding(false, true);
                label = sjis ? "CP932（指定）" : "UTF-8（指定）";
            }
            return enc.GetString(bytes, offset, bytes.Length - offset);
        }
        internal static XmlWriter Writer(ZipArchive zip, string path) {
            return XmlWriter.Create(zip.CreateEntry(path, CompressionLevel.Optimal).Open(), new XmlWriterSettings { Encoding = new UTF8Encoding(false), CloseOutput = true });
        }
        static void Cell(XmlWriter x, string value, int style) {
            x.WriteStartElement("c", Ns); x.WriteAttributeString("t", "inlineStr"); x.WriteAttributeString("s", style.ToString());
            x.WriteStartElement("is", Ns); x.WriteStartElement("t", Ns);
            x.WriteAttributeString("xml", "space", "http://www.w3.org/XML/1998/namespace", "preserve");
            // Escape OOXML escape sequences so literal source text such as _x0041_ survives Excel loading.
            x.WriteString(Regex.Replace(value ?? "", "_x[0-9a-fA-F]{4}_", m => "_x005F_" + m.Value.Substring(1)));
            x.WriteEndElement(); x.WriteEndElement(); x.WriteEndElement();
        }
        internal static void Row(XmlWriter x, string[] values, int style, int height = 0) {
            x.WriteStartElement("row", Ns);
            if (height > 0) { x.WriteAttributeString("ht", height.ToString()); x.WriteAttributeString("customHeight", "1"); }
            foreach (string v in values) Cell(x, v, style);
            x.WriteEndElement();
        }
        internal static void BeginSheet(XmlWriter x, double[] widths, int freeze) {
            x.WriteStartElement("worksheet", Ns);
            x.WriteStartElement("sheetViews", Ns); x.WriteStartElement("sheetView", Ns); x.WriteAttributeString("workbookViewId", "0");
            x.WriteStartElement("pane", Ns); x.WriteAttributeString("ySplit", freeze.ToString()); x.WriteAttributeString("topLeftCell", "A" + (freeze + 1)); x.WriteAttributeString("activePane", "bottomLeft"); x.WriteAttributeString("state", "frozen"); x.WriteEndElement();
            x.WriteEndElement(); x.WriteEndElement(); x.WriteStartElement("cols", Ns);
            for (int i = 0; i < widths.Length; i++) { x.WriteStartElement("col", Ns); x.WriteAttributeString("min", (i+1).ToString()); x.WriteAttributeString("max", (i+1).ToString()); x.WriteAttributeString("width", widths[i].ToString(System.Globalization.CultureInfo.InvariantCulture)); x.WriteAttributeString("customWidth", "1"); x.WriteEndElement(); }
            x.WriteEndElement(); x.WriteStartElement("sheetData", Ns);
        }
        internal static void EndSheet(XmlWriter x, string filter, string[] merges = null) {
            x.WriteEndElement();
            if (filter != null) { x.WriteStartElement("autoFilter", Ns); x.WriteAttributeString("ref", filter); x.WriteEndElement(); }
            if (merges != null) {
                x.WriteStartElement("mergeCells", Ns); x.WriteAttributeString("count", merges.Length.ToString());
                foreach (string range in merges) { x.WriteStartElement("mergeCell", Ns); x.WriteAttributeString("ref", range); x.WriteEndElement(); }
                x.WriteEndElement();
            }
            x.WriteEndElement();
        }
        static void Raw(ZipArchive zip, string path, string content) { using (var w = new StreamWriter(zip.CreateEntry(path).Open(), new UTF8Encoding(false))) w.Write(content); }
        static void Package(ZipArchive zip, List<string> sheets) {
            const string rel = "http://schemas.openxmlformats.org/package/2006/relationships";
            const string office = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
            using (var x = Writer(zip, "[Content_Types].xml")) {
                x.WriteStartElement("Types", "http://schemas.openxmlformats.org/package/2006/content-types");
                foreach (var p in new[] { new[] { "rels", "application/vnd.openxmlformats-package.relationships+xml" }, new[] { "xml", "application/xml" } }) { x.WriteStartElement("Default"); x.WriteAttributeString("Extension", p[0]); x.WriteAttributeString("ContentType", p[1]); x.WriteEndElement(); }
                for (int i = -1; i <= sheets.Count; i++) { x.WriteStartElement("Override"); x.WriteAttributeString("PartName", i == -1 ? "/xl/styles.xml" : i == 0 ? "/xl/workbook.xml" : "/xl/worksheets/sheet" + i + ".xml"); x.WriteAttributeString("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml." + (i == -1 ? "styles" : i == 0 ? "sheet.main" : "worksheet") + "+xml"); x.WriteEndElement(); }
                x.WriteEndElement();
            }
            Raw(zip, "_rels/.rels", "<Relationships xmlns=\"" + rel + "\"><Relationship Id=\"rId1\" Type=\"" + office + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            using (var x = Writer(zip, "xl/_rels/workbook.xml.rels")) {
                x.WriteStartElement("Relationships", rel);
                for (int i = 0; i <= sheets.Count; i++) { x.WriteStartElement("Relationship", rel); x.WriteAttributeString("Id", "rId" + (i+1)); x.WriteAttributeString("Type", office + (i == sheets.Count ? "/styles" : "/worksheet")); x.WriteAttributeString("Target", i == sheets.Count ? "styles.xml" : "worksheets/sheet" + (i+1) + ".xml"); x.WriteEndElement(); }
                x.WriteEndElement();
            }
            using (var x = Writer(zip, "xl/workbook.xml")) {
                x.WriteStartElement("workbook", Ns); x.WriteStartElement("sheets", Ns);
                for (int i = 0; i < sheets.Count; i++) { x.WriteStartElement("sheet", Ns); x.WriteAttributeString("name", sheets[i]); x.WriteAttributeString("sheetId", (i+1).ToString()); x.WriteAttributeString("r", "id", office, "rId" + (i+1)); x.WriteEndElement(); }
                x.WriteEndElement(); x.WriteEndElement();
            }
            Raw(zip, "xl/styles.xml", "<styleSheet xmlns=\"" + Ns + "\"><fonts count=\"3\"><font><sz val=\"11\"/><name val=\"Yu Gothic\"/></font><font><b/><color rgb=\"FFFFFFFF\"/><sz val=\"11\"/><name val=\"Yu Gothic\"/></font><font><sz val=\"11\"/><name val=\"Consolas\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF24476A\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"1\"><border/></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"3\"><xf numFmtId=\"49\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf><xf numFmtId=\"49\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"49\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
        }
        public static string Run(Options o, Action<int,string> progress, Func<bool> cancel) {
            if (o.Folders.Count == 0) throw new ArgumentException("フォルダを追加してください。");
            string output = System.IO.Path.GetFullPath(o.Output);
            if (!output.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("保存先は .xlsx を指定してください。");
            if (File.Exists(output)) throw new IOException("保存先は既に存在します。別のファイル名を指定してください。");
            if (File.Exists(output + ".sources.zip")) throw new IOException("同名の原本データが存在します。別のファイル名を指定してください。");
            var extensions = new HashSet<string>(o.Extensions.Split(new[] { ' ', ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Select(e => "." + e.TrimStart('.')), StringComparer.OrdinalIgnoreCase);
            if (extensions.Count == 0) throw new ArgumentException("拡張子を指定してください。");
            var records = new List<Record>(); var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            progress(0, "フォルダを調べています…");
            foreach (string folder in o.Folders) {
                string root = System.IO.Path.GetFullPath(folder);
                if (!Directory.Exists(root)) throw new DirectoryNotFoundException(root);
                Scan(root, root, o, records, seen, cancel);
            }
            if (records.Count > 100000) throw new IOException("対象が10万件を超えます。フォルダを絞ってください。");
            string temp = output + "." + Guid.NewGuid().ToString("N") + ".tmp";
            int imported = 0, errors = 0;
            string packTemp = temp + ".sources";
            bool movedPack = false;
            try {
                using (var pack = new SourcePackWriter(packTemp))
                using (var zip = new ZipArchive(new FileStream(temp, FileMode.CreateNew), ZipArchiveMode.Create)) {
                    var sheets = new List<string> { "ファイル一覧", "作業指示", "修正案" };
                    WorkbookWorkflow.WriteSheets(zip, pack.Id);
                    int processed = 0;
                    foreach (Record r in records) {
                        Check(cancel);
                        progress(records.Count == 0 ? 0 : (int)(100.0 * processed++ / records.Count), "読み込み: " + System.IO.Path.GetFileName(r.Path));
                        if (r.Status != null) continue;
                        if ((File.GetAttributes(r.Path) & FileAttributes.ReparsePoint) != 0) { r.Status = "除外"; r.Note = "リンクファイル"; continue; }
                        if (!extensions.Contains(System.IO.Path.GetExtension(r.Path))) { r.Status = "除外"; r.Note = "対象外の拡張子"; continue; }
                        if (o.Keyword.Length > 0 && System.IO.Path.GetFileName(r.Path).IndexOf(o.Keyword, StringComparison.OrdinalIgnoreCase) < 0) { r.Status = "除外"; r.Note = "ファイル名の絞り込み"; continue; }
                        string text; string[] lines; byte[] bytes;
                        try {
                            if (new FileInfo(r.Path).Length > 5 * 1024 * 1024) throw new IOException("5MBを超えるファイルです。");
                            bytes = File.ReadAllBytes(r.Path);
                            using (var sha = SHA256.Create()) r.Hash = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
                            text = Decode(bytes, o.EncodingName, out r.Encoding);
                            XmlConvert.VerifyXmlChars(text);
                            lines = text.Length == 0 ? new string[0] : Regex.Split(text, "\r\n|\n|\r");
                            if (lines.Length > 1048570) throw new IOException("Excelの行数上限を超えます。");
                            if (lines.Any(l => l.Length > 32767)) throw new IOException("1行がExcelのセル上限32,767文字を超えます。");
                        } catch (Exception ex) {
                            if (!(ex is IOException || ex is UnauthorizedAccessException || ex is DecoderFallbackException || ex is XmlException)) throw;
                            r.Status = "エラー"; r.Note = ex.Message; errors++; continue;
                        }
                        if (imported >= 500) throw new IOException("500ファイルを超えます。画面やフォルダを絞ってください。");
                        string name = Regex.Replace(System.IO.Path.GetFileName(r.Path), "[\\[\\]:*?/\\\\'\u0000-\u001f]", "_");
                        r.Sheet = (imported + 1).ToString("D4") + "_" + name.Substring(0, Math.Min(26, name.Length));
                        r.Lines = lines.Length; r.Status = "取込済";
                        int crlf = Regex.Matches(text, "\r\n").Count, lf = Regex.Matches(text, "(?<!\r)\n").Count, cr = Regex.Matches(text, "\r(?!\n)").Count;
                        r.Note = "CRLF=" + crlf + " / LF=" + lf + " / CR=" + cr + " / 末尾改行=" + (text.EndsWith("\n") || text.EndsWith("\r") ? "あり" : "なし");
                        pack.Add(r, bytes);
                        sheets.Add(r.Sheet);
                        using (var x = Writer(zip, "xl/worksheets/sheet" + sheets.Count + ".xml")) {
                            BeginSheet(x, new[] { 12.0, 120.0 }, 4);
                            Row(x, new[] { "ファイル", r.Path }, 0);
                            Row(x, new[] { "文字コード", r.Encoding }, 0);
                            Row(x, new[] { "改行", r.Note }, 0);
                            Row(x, new[] { "行番号", "コード" }, 1);
                            for (int j = 0; j < lines.Length; j++) { if (j % 1000 == 0) Check(cancel); Row(x, new[] { (j+1).ToString(), lines[j] }, 2); }
                            EndSheet(x, null);
                        }
                        imported++;
                    }
                    using (var x = Writer(zip, "xl/worksheets/sheet1.xml")) {
                        BeginSheet(x, new[] { 16.0, 36.0, 60.0, 40.0, 28.0, 12.0, 70.0, 68.0 }, 4);
                        Row(x, new[] { "ソース取込", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "取込済 " + imported + " / エラー " + errors + " / 除外 " + records.Count(r => r.Status == "除外") }, 0);
                        Row(x, new[] { "使い方", "作業指示を記入し、Copilotへ依頼してください。修正は修正案シートへ記入します。元コードのシートは変更しないでください。" }, 0);
                        Row(x, new[] { "取込条件", "サブフォルダ=" + o.Recursive + " / ファイル名=" + o.Keyword + " / 拡張子=" + o.Extensions }, 0);
                        Row(x, new[] { "状態", "シート名", "元ファイル", "指定フォルダ", "文字コード", "格納行数", "備考", "SHA-256" }, 1);
                        foreach (Record r in records) Row(x, new[] { r.Status, r.Sheet, r.Path, r.Root, r.Encoding, r.Lines.ToString(), r.Note, r.Hash }, 0);
                        EndSheet(x, records.Count > 0 ? "A4:H" + (records.Count + 4) : null);
                    }
                    Package(zip, sheets);
                }
                Check(cancel);
                File.Move(packTemp, output + ".sources.zip"); movedPack = true;
                try { File.Move(temp, output); }
                catch { if (movedPack) File.Delete(output + ".sources.zip"); throw; }
            } finally { if (File.Exists(temp)) File.Delete(temp); if (File.Exists(packTemp)) File.Delete(packTemp); }
            progress(100, "完了");
            return "取込済: " + imported + "件 / エラー: " + errors + "件 / 除外: " + records.Count(r => r.Status == "除外") + "件\r\n" + output + (imported == 0 ? "\r\n対象コードはありません。ファイル一覧で理由を確認してください。" : "") + (errors > 0 ? "\r\nファイル一覧のエラーを確認してください。" : "");
        }
    }
    public class MainForm : Form {
        readonly ListBox folders = new ListBox();
        readonly TextBox output = new TextBox(), keyword = new TextBox(), extensions = new TextBox();
        readonly ComboBox encoding = new ComboBox();
        readonly CheckBox recursive = new CheckBox();
        readonly Button start = new Button(), cancel = new Button();
        readonly Label status = new Label();
        readonly ProgressBar progress = new ProgressBar();
        readonly BackgroundWorker worker = new BackgroundWorker();
        readonly List<Control> editable = new List<Control>();
        public MainForm() {
            Text = "Excel Copilot コード作業ツール"; ClientSize = new Size(920, 690); MinimumSize = new Size(940, 730);
            Font = new Font("Yu Gothic UI", 10); BackColor = Color.FromArgb(245, 247, 250); StartPosition = FormStartPosition.CenterScreen;
            var grid = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(24), ColumnCount = 3, RowCount = 12 };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 135)); grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            float[] heights = { 44, 36, 146, 38, 42, 42, 60, 44, 44, 28, 65, 20 };
            foreach (float h in heights) grid.RowStyles.Add(new RowStyle(SizeType.Absolute, h));
            Controls.Add(grid);
            var title = new Label { Text = "フォルダのコードを、1ファイル1シートへ。", Font = new Font(Font.FontFamily, 16, FontStyle.Bold), Dock = DockStyle.Fill };
            grid.Controls.Add(title, 0, 0); grid.SetColumnSpan(title, 3);
            var help = new Label { Text = "VB・Web・仕様資料のフォルダを追加し、保存先を選んでください。", Dock = DockStyle.Fill };
            grid.Controls.Add(help, 0, 1); grid.SetColumnSpan(help, 3);
            grid.Controls.Add(new Label { Text = "対象フォルダ", AutoSize = true }, 0, 2);
            folders.Dock = DockStyle.Fill; folders.HorizontalScrollbar = true; grid.Controls.Add(folders, 1, 2);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown };
            var add = new Button { Text = "追加…", Width = 110, Height = 36 };
            var remove = new Button { Text = "削除", Width = 110, Height = 36 };
            buttons.Controls.Add(add); buttons.Controls.Add(remove); grid.Controls.Add(buttons, 2, 2);
            add.Click += delegate { using (var d = new FolderBrowserDialog { Description = "取り込むフォルダを選択", ShowNewFolderButton = false }) { if (d.ShowDialog(this) == DialogResult.OK && !folders.Items.Contains(d.SelectedPath)) folders.Items.Add(d.SelectedPath); } };
            remove.Click += delegate { if (folders.SelectedIndex >= 0) folders.Items.RemoveAt(folders.SelectedIndex); };
            recursive.Text = "サブフォルダも取り込む"; recursive.Checked = true; recursive.AutoSize = true; grid.Controls.Add(recursive, 1, 3);
            AddField(grid, "ファイル名に含む", keyword, 4); keyword.Text = "";
            encoding.DropDownStyle = ComboBoxStyle.DropDownList; encoding.Items.AddRange(new object[] { "自動", "UTF-8", "CP932" }); encoding.SelectedIndex = 0; AddField(grid, "文字コード", encoding, 5);
            extensions.Text = new Options().Extensions; extensions.Multiline = true; extensions.ScrollBars = ScrollBars.Vertical; AddField(grid, "対象拡張子", extensions, 6);
            AddField(grid, "保存先 (.xlsx)", output, 7);
            output.Text = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "ソース取込_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx");
            var save = new Button { Text = "保存先…", Dock = DockStyle.Fill }; grid.Controls.Add(save, 2, 7);
            save.Click += delegate { using (var d = new SaveFileDialog { Filter = "Excel ブック|*.xlsx", FileName = System.IO.Path.GetFileName(output.Text), OverwritePrompt = true }) { if (d.ShowDialog(this) == DialogResult.OK) output.Text = d.FileName; } };
            var actions = new FlowLayoutPanel { Dock = DockStyle.Fill };
            start.Text = "Excelを作成"; start.Size = new Size(155, 36); start.BackColor = Color.FromArgb(36, 71, 106); start.ForeColor = Color.White; start.FlatStyle = FlatStyle.Flat;
            cancel.Text = "中止"; cancel.Size = new Size(90, 36); cancel.Enabled = false;
            actions.Controls.Add(start); actions.Controls.Add(cancel); grid.Controls.Add(actions, 1, 8);
            var review = new Button { Text = "修正案を確認…", Size = new Size(160, 36) };
            actions.Controls.Add(review); grid.SetColumnSpan(actions, 2); editable.Add(review);
            review.Click += delegate {
                using (var d = new OpenFileDialog { Filter = "Excel ブック|*.xlsx", Title = "Copilotで修正案を記入して保存したExcelを選択" }) {
                    if (d.ShowDialog(this) != DialogResult.OK) return;
                    try { Cursor = Cursors.WaitCursor; var plan = ChangePlan.Load(d.FileName); using (var dialog = new ReviewForm(plan)) { Cursor = Cursors.Default; dialog.ShowDialog(this); } }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "修正案の確認", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                    finally { Cursor = Cursors.Default; }
                }
            };
            progress.Dock = DockStyle.Fill; grid.Controls.Add(progress, 0, 9); grid.SetColumnSpan(progress, 3);
            status.Text = "元ファイルは変更しません。空欄のファイル名条件は全件対象です。"; status.Dock = DockStyle.Fill; status.AutoEllipsis = true;
            grid.Controls.Add(status, 0, 10); grid.SetColumnSpan(status, 3);
            editable.AddRange(new Control[] { folders, add, remove, recursive, keyword, encoding, extensions, output, save, start });
            worker.WorkerReportsProgress = true; worker.WorkerSupportsCancellation = true;
            worker.DoWork += delegate(object sender, DoWorkEventArgs e) {
                try { e.Result = Importer.Run((Options)e.Argument, (n,s) => worker.ReportProgress(n, s), () => worker.CancellationPending); }
                catch (OperationCanceledException) { e.Cancel = true; }
            };
            worker.ProgressChanged += delegate(object sender, ProgressChangedEventArgs e) { progress.Value = e.ProgressPercentage; status.Text = (string)e.UserState; };
            worker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs e) {
                foreach (var c in editable) c.Enabled = true; cancel.Enabled = false;
                status.Text = e.Cancelled ? "中止しました。出力ファイルは作成していません。" : e.Error != null ? "エラー: " + e.Error.Message : (string)e.Result;
                if (e.Error != null) MessageBox.Show(this, e.Error.Message, "取り込みエラー", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            };
            start.Click += delegate {
                var o = new Options { Output = output.Text.Trim(), Keyword = keyword.Text.Trim(), Extensions = extensions.Text, EncodingName = (string)encoding.SelectedItem, Recursive = recursive.Checked };
                foreach (string folder in folders.Items) o.Folders.Add(folder);
                if (o.Folders.Count == 0 || o.Output.Length == 0) { MessageBox.Show(this, "対象フォルダと保存先を指定してください。"); return; }
                foreach (var c in editable) c.Enabled = false; cancel.Enabled = true; progress.Value = 0; worker.RunWorkerAsync(o);
            };
            cancel.Click += delegate { worker.CancelAsync(); cancel.Enabled = false; status.Text = "中止しています…"; };
            FormClosing += delegate(object sender, FormClosingEventArgs e) { if (worker.IsBusy) { e.Cancel = true; worker.CancelAsync(); status.Text = "中止後に閉じてください。"; } };
        }
        void AddField(TableLayoutPanel p, string label, Control input, int row) { p.Controls.Add(new Label { Text = label, AutoSize = true, Padding = new Padding(0, 6, 0, 0) }, 0, row); input.Dock = DockStyle.Fill; p.Controls.Add(input, 1, row); }
    }
    public static class Program {
        static void PreparePreview(Control c) { var handle = c.Handle; foreach (Control child in c.Controls) PreparePreview(child); c.PerformLayout(); }
        [STAThread] public static int Main(string[] args) {
            if (args.Length >= 3 && args[0] == "--import") {
                try { var o = new Options { Output = args[1] }; o.Folders.AddRange(args.Skip(2)); string result = Importer.Run(o, (n,s) => {}, () => false); File.WriteAllText(args[1] + ".log", result, Encoding.UTF8); return 0; }
                catch (Exception ex) { File.WriteAllText(args[1] + ".error.log", ex.ToString(), Encoding.UTF8); return 1; }
            }
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length == 3 && args[0] == "--preview-review") {
                using (var form = new ReviewForm(ChangePlan.Load(args[1]))) { PreparePreview(form); using (var bmp = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bmp, new Rectangle(0,0,form.Width,form.Height)); bmp.Save(args[2]); } }
                return 0;
            }
            using (var form = new MainForm()) {
                if (args.Length == 2 && args[0] == "--preview") { PreparePreview(form); using (var bmp = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bmp, new Rectangle(0,0,form.Width,form.Height)); bmp.Save(args[1]); } return 0; }
                Application.Run(form);
            }
            return 0;
        }
    }
}
