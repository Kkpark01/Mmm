using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace SourceExcelImporter {
    public sealed class ReviewForm : Form {
        readonly ChangePlan plan;
        readonly CheckedListBox files = new CheckedListBox();
        readonly RichTextBox diff = Editor(), before = Editor(), after = Editor();
        readonly Label status = new Label();
        static RichTextBox Editor() { return new RichTextBox { Dock = DockStyle.Fill, ReadOnly = true, WordWrap = false, Font = new Font("Consolas", 11), BackColor = Color.White, DetectUrls = false }; }
        public ReviewForm(ChangePlan changePlan) {
            plan = changePlan;
            Text = "修正案の確認・書き出し"; ClientSize = new Size(1140, 760); MinimumSize = new Size(940, 650); StartPosition = FormStartPosition.CenterParent;
            Font = new Font("Yu Gothic UI", 10);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(16), RowCount = 4, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55)); Controls.Add(layout);
            layout.Controls.Add(new Label { Text = "差分を確認し、保存するファイルだけチェックしてください。元ソースは変更しません。", Dock = DockStyle.Fill }, 0, 0);
            var split = new SplitContainer { Size = new Size(1100, 570), Dock = DockStyle.Fill, Panel1MinSize = 240, SplitterDistance = 300, FixedPanel = FixedPanel.Panel1 };
            layout.Controls.Add(split, 0, 1); files.Dock = DockStyle.Fill; files.HorizontalScrollbar = true; files.CheckOnClick = false; split.Panel1.Controls.Add(files);
            foreach (var file in plan.Files) files.Items.Add(file, false);
            var tabs = new TabControl { Dock = DockStyle.Fill }; split.Panel2.Controls.Add(tabs);
            var changes = new TabPage("変更箇所（－削除 ／ ＋追加）"); changes.Controls.Add(diff); tabs.TabPages.Add(changes);
            var full = new TabPage("全文比較"); var pair = new SplitContainer { Dock = DockStyle.Fill }; pair.Panel1.Controls.Add(before); pair.Panel2.Controls.Add(after); full.Controls.Add(pair); tabs.TabPages.Add(full);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill };
            var save = new Button { Text = "選択した修正版を保存…", Width = 230, Height = 36 };
            var all = new Button { Text = "すべて選択", Width = 120, Height = 36 }; var none = new Button { Text = "選択を解除", Width = 120, Height = 36 };
            buttons.Controls.Add(save); buttons.Controls.Add(all); buttons.Controls.Add(none); layout.Controls.Add(buttons, 0, 2);
            status.Dock = DockStyle.Fill; status.Text = "ファイルを選ぶと差分を表示します。チェックを入れたファイルの全修正を保存します。"; layout.Controls.Add(status, 0, 3);
            files.SelectedIndexChanged += delegate { ShowChange(); };
            all.Click += delegate { for (int i = 0; i < files.Items.Count; i++) files.SetItemChecked(i, true); };
            none.Click += delegate { for (int i = 0; i < files.Items.Count; i++) files.SetItemChecked(i, false); };
            save.Click += delegate {
                if (files.CheckedItems.Count == 0) { MessageBox.Show(this, "保存するファイルにチェックを入れてください。"); return; }
                using (var d = new FolderBrowserDialog { Description = "修正版フォルダを作成する場所を選択（例: MCMの修正コード）" }) {
                    d.SelectedPath = Path.GetDirectoryName(plan.WorkbookPath);
                    if (d.ShowDialog(this) != DialogResult.OK) return;
                    try { Cursor = Cursors.WaitCursor; string path = plan.Export(d.SelectedPath, files.CheckedItems.Cast<FileChange>()); status.Text = "保存しました（ビルド・動作検証は未実施）\r\n" + path; }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "書き出しできません", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                    finally { Cursor = Cursors.Default; }
                }
            };
            if (files.Items.Count > 0) files.SelectedIndex = 0;
        }
        void ShowChange() {
            var file = files.SelectedItem as FileChange; if (file == null) return;
            before.Text = "【元コード】\r\n" + file.Original; after.Text = "【修正後】\r\n" + file.Revised;
            diff.Clear();
            foreach (string line in file.Diff().Split('\n')) {
                diff.SelectionColor = line.StartsWith("- ") ? Color.Firebrick : line.StartsWith("+ ") ? Color.DarkGreen : Color.Black;
                diff.AppendText(line.TrimEnd('\r') + "\n");
            }
            diff.Select(0, 0); diff.ScrollToCaret();
            status.Text = file.SourcePath + "\r\n文字コード: " + file.EncodingName;
        }
    }
}
