using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace SourceExcelImporter {
    internal static class WorkbookWorkflow {
        public static readonly string[] Headers = { "対象シート", "開始行", "終了行", "置換後コード", "置換後行数", "変更理由" };
        public static void WriteSheets(ZipArchive zip, string id) {
            using (var x = Importer.Writer(zip, "xl/worksheets/sheet2.xml")) {
                Importer.BeginSheet(x, new[] { 25.0, 115.0 }, 1);
                var rows = new[] {
                    new[] { "項目", "入力・説明" },
                    new[] { "対象画面", "ここに対象画面を記入" },
                    new[] { "依頼内容", "ここに直したい動作を記入" },
                    new[] { "VBのシート名", "ファイル一覧から比較元のシート名を記入" },
                    new[] { "Webのシート名", "ファイル一覧から修正対象のシート名を記入" },
                    new[] { "適用仕様", "共通仕様・合意事項のシート名と該当箇所を記入" },
                    new[] { "Copilotへの依頼文", "このブックの作業指示B2:B6を読み、指定されたVBを基準にWebの修正案を作成してください。仕様とVBが衝突する場合は修正せず質問してください。指定されていないファイルやVBは修正しないでください。元コードのシートは変更せず、修正案シートA5:F列へ1変更範囲につき1行で記入してください。開始行・終了行はExcelの行番号ではなく元コードA列の行番号です。D列はその範囲の置換コード全文（セル内改行あり、説明・省略記号・Markdownの囲みなし）、E列はそのセルの正確な行数、F列はVB・仕様の根拠と変更理由です。削除はD列空欄・E列0、挿入は終了行=開始行-1としてください。すべての行番号は取込時の元コードを基準にし、範囲を重複させないでください。1セル32,767文字以内に収め、大きな修正は重ならない範囲に分割してください。未確認の動作を検証済みとは書かないでください。" },
                    new[] { "操作手順", "B2:B6を記入 → B7の文章をCopilotへ送信 → 修正案を確認してExcelを保存 → アプリの「修正案を確認…」 → 保存するファイルをチェックして書き出し" },
                    new[] { "原本データ", "このExcelと同じ場所の .xlsx.sources.zip を保管してください。Excelを別名保存・移動するときは原本データも同じ名前へ変更・移動してください。" },
                    new[] { "管理ID（変更不可）", id },
                    new[] { "検証状況", "この版は差分確認・書き出しまでです。ビルド・動作確認は別途実施してください。" },
                    new[] { "行の数え方", "空行も1行です。末尾改行のある元コードは最後の空行も保持しています。D列の末尾改行も追加の空行として数えます。" }
                };
                int[] heights = { 24, 32, 48, 48, 48, 56, 200, 70, 60, 28, 42, 54 };
                for (int i = 0; i < rows.Length; i++) Importer.Row(x, rows[i], i == 0 ? 1 : 0, heights[i]);
                Importer.EndSheet(x, null);
            }
            using (var x = Importer.Writer(zip, "xl/worksheets/sheet3.xml")) {
                Importer.BeginSheet(x, new[] { 36.0, 12.0, 12.0, 110.0, 16.0, 65.0 }, 4);
                Importer.Row(x, new[] { "修正案", "5行目以降に記入。元コードのシートは編集しないでください。" }, 0, 30);
                Importer.Row(x, new[] { "置換・削除", "開始行～終了行をD列の内容で置換。削除はD列空欄、E列0。" }, 0, 30);
                Importer.Row(x, new[] { "挿入", "開始行の直前に追加。終了行は開始行-1。行番号は元コードA列が基準です。" }, 0, 30);
                Importer.Row(x, Headers, 1);
                for (int i = 0; i < 20; i++) Importer.Row(x, new[] { "", "", "", "", "", "" }, 0);
                Importer.EndSheet(x, "A4:F24", new[] { "B1:F1", "B2:F2", "B3:F3" });
            }
        }
    }
    internal sealed class SourcePackWriter : IDisposable {
        public readonly string Id = Guid.NewGuid().ToString("N");
        readonly ZipArchive zip;
        readonly List<XElement> files = new List<XElement>();
        readonly List<string> roots = new List<string>();
        public SourcePackWriter(string path) { zip = new ZipArchive(new FileStream(path, FileMode.CreateNew), ZipArchiveMode.Create); }
        public void Add(Record r, byte[] bytes) {
            int root = roots.FindIndex(p => string.Equals(p, r.Root, StringComparison.OrdinalIgnoreCase));
            if (root < 0) { root = roots.Count; roots.Add(r.Root); }
            string entry = "originals/" + (files.Count + 1).ToString("D4") + ".bin";
            using (var stream = zip.CreateEntry(entry).Open()) stream.Write(bytes, 0, bytes.Length);
            string relative = r.Path.Substring(r.Root.TrimEnd(Path.DirectorySeparatorChar).Length).TrimStart(Path.DirectorySeparatorChar);
            string folderName = Path.GetFileName(r.Root.TrimEnd(Path.DirectorySeparatorChar));
            folderName = Regex.Replace(folderName, "[^\\p{L}\\p{N}_.-]", "_");
            files.Add(new XElement("file", new XAttribute("sheet", r.Sheet), new XAttribute("path", r.Path),
                new XAttribute("relative", (root + 1).ToString("D2") + "_" + folderName + "/" + relative.Replace('\\', '/')),
                new XAttribute("encoding", r.Encoding), new XAttribute("sha256", r.Hash), new XAttribute("entry", entry)));
        }
        public void Dispose() {
            try { using (var x = Importer.Writer(zip, "manifest.xml")) new XDocument(new XElement("sources", new XAttribute("version", "2"), new XAttribute("id", Id), files)).Save(x); }
            finally { zip.Dispose(); }
        }
    }
    internal sealed class SheetCell {
        public string Value = "", Type;
        public bool Formula;
    }
    internal sealed class WorkbookReader : IDisposable {
        internal static readonly XNamespace Ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        readonly ZipArchive zip;
        readonly List<string> shared;
        readonly Dictionary<string, string> sheets;
        public WorkbookReader(string path) {
            zip = new ZipArchive(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read), ZipArchiveMode.Read);
            try {
                if (zip.Entries.Sum(e => e.Length) > 256L * 1024 * 1024) throw new IOException("Excelの展開サイズが256MBを超えます。取り込み範囲を絞ってください。");
                var strings = zip.GetEntry("xl/sharedStrings.xml");
                shared = strings == null ? new List<string>() : ReadXml(strings).Root.Elements(Ns + "si").Select(TextValue).ToList();
                var rels = ReadXml(zip.GetEntry("xl/_rels/workbook.xml.rels")).Root.Elements().ToDictionary(e => (string)e.Attribute("Id"));
                sheets = new Dictionary<string, string>();
                foreach (var sheet in ReadXml(zip.GetEntry("xl/workbook.xml")).Descendants(Ns + "sheet")) {
                    string id = (string)sheet.Attribute(XName.Get("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships"));
                    var rel = rels[id];
                    if ((string)rel.Attribute("TargetMode") == "External") throw new IOException("外部シートは読み込めません。");
                    var uri = new Uri(new Uri("http://workbook/xl/workbook.xml"), (string)rel.Attribute("Target"));
                    if (uri.Host != "workbook") throw new IOException("不正なシート参照です。");
                    sheets.Add((string)sheet.Attribute("name"), Uri.UnescapeDataString(uri.AbsolutePath.TrimStart('/')));
                }
            } catch { zip.Dispose(); throw; }
        }
        internal static XDocument ReadXml(ZipArchiveEntry entry) {
            if (entry == null) throw new IOException("必要なExcel／原本データがありません。");
            if (entry.Length > 128L * 1024 * 1024) throw new IOException("XMLデータが大きすぎます。");
            using (var stream = entry.Open())
            using (var reader = XmlReader.Create(stream, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 128L * 1024 * 1024 })) return XDocument.Load(reader);
        }
        static string TextValue(XElement e) {
            // Decode each OOXML escape once, including literal escaped underscores.
            string text = string.Concat(e.Descendants(Ns + "t").Where(t => !t.Ancestors(Ns + "rPh").Any()).Select(t => t.Value));
            return Regex.Replace(text, "_x([0-9a-fA-F]{4})_", m => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString());
        }
        public SortedDictionary<int, Dictionary<int, SheetCell>> Read(string name) {
            if (!sheets.ContainsKey(name)) throw new IOException("「" + name + "」シートがありません。新しいアプリで取り込み直してください。");
            var data = new SortedDictionary<int, Dictionary<int, SheetCell>>();
            int nextRow = 1;
            foreach (var row in ReadXml(zip.GetEntry(sheets[name])).Descendants(Ns + "sheetData").Elements(Ns + "row")) {
                int rowNo = row.Attribute("r") == null ? nextRow : (int)row.Attribute("r"); nextRow = rowNo + 1;
                var cells = new Dictionary<int, SheetCell>(); int nextColumn = 1;
                foreach (var cell in row.Elements(Ns + "c")) {
                    string reference = (string)cell.Attribute("r"); int col = nextColumn;
                    if (reference != null) { col = 0; foreach (char c in reference.TakeWhile(char.IsLetter)) col = checked(col * 26 + char.ToUpperInvariant(c) - 'A' + 1); }
                    if (col < 1 || col > 16384) throw new IOException("不正なセル位置です。");
                    nextColumn = col + 1;
                    string type = (string)cell.Attribute("t"), value = (string)cell.Element(Ns + "v") ?? "";
                    if (type == "inlineStr") value = TextValue(cell);
                    else if (type == "s") { int index; if (!int.TryParse(value, out index) || index < 0 || index >= shared.Count) throw new IOException("不正な共有文字列です。"); value = shared[index]; }
                    cells.Add(col, new SheetCell { Value = value, Type = type, Formula = cell.Element(Ns + "f") != null });
                }
                data.Add(rowNo, cells);
            }
            return data;
        }
        internal static SheetCell Get(Dictionary<int, SheetCell> row, int col) { SheetCell cell; return row.TryGetValue(col, out cell) ? cell : new SheetCell(); }
        public void Dispose() { zip.Dispose(); }
    }
    public sealed class EditBlock {
        public int Row, Start, End;
        public string[] Replacement;
        public string Reason;
    }
    public sealed class FileChange {
        public string Sheet, SourcePath, RelativePath, Original, Revised, OriginalHash, EncodingName;
        public byte[] Bytes;
        public readonly List<EditBlock> Edits = new List<EditBlock>();
        public string Diff() {
            string[] lines = ChangePlan.Lines(Original);
            var result = new StringBuilder();
            foreach (var edit in Edits) {
                result.AppendLine("@@ 元コード " + edit.Start + "～" + edit.End + "行 / 修正案シート " + edit.Row + "行 @@");
                result.AppendLine("理由: " + edit.Reason);
                for (int i = edit.Start - 1; i < edit.End; i++) result.AppendLine("- " + lines[i]);
                foreach (string line in edit.Replacement) result.AppendLine("+ " + line);
                result.AppendLine();
            }
            return result.ToString();
        }
        public override string ToString() { return RelativePath + " （" + Edits.Count + "箇所）"; }
    }
    public sealed class ChangePlan {
        public readonly List<FileChange> Files = new List<FileChange>();
        public string WorkbookPath, PackPath;
        string workbookHash, packHash;
        internal static string[] Lines(string text) { return text.Length == 0 ? new string[0] : Regex.Split(text, "\r\n|\r|\n"); }
        internal static string Hash(byte[] bytes) { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        static string FileHash(string path) { using (var stream = File.OpenRead(path)) using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant(); }
        static string Attribute(XElement e, string name) { var a = e.Attribute(name); if (a == null) throw new IOException("原本データの " + name + " がありません。"); return a.Value; }
        static void ValidateRelative(string path) {
            if (string.IsNullOrWhiteSpace(path) || Path.IsPathRooted(path) || path.Split('/', '\\').Any(p => p.Length == 0 || p == "." || p == ".." || p.EndsWith(".") || p.EndsWith(" ") || p.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)) throw new IOException("不正な保存先パスです: " + path);
        }
        static byte[] Encode(string text, byte[] original, string label) {
            Encoding enc;
            if (label.StartsWith("CP932")) enc = Encoding.GetEncoding(932, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback);
            else if (label.StartsWith("UTF-32")) enc = new UTF32Encoding(label.Contains("BE"), true, true);
            else if (label.StartsWith("UTF-16")) enc = new UnicodeEncoding(label.Contains("BE"), true, true);
            else enc = new UTF8Encoding(label.Contains("BOM"), true);
            return enc.GetPreamble().Concat(enc.GetBytes(text)).ToArray();
        }
        public static ChangePlan Load(string workbook) {
            var plan = new ChangePlan { WorkbookPath = Path.GetFullPath(workbook), PackPath = Path.GetFullPath(workbook) + ".sources.zip" };
            if (!File.Exists(plan.PackPath)) throw new IOException("原本データがありません。Excelと同じ場所に「" + Path.GetFileName(plan.PackPath) + "」を置いてください。旧版のExcelは再取り込みが必要です。");
            plan.workbookHash = FileHash(plan.WorkbookPath); plan.packHash = FileHash(plan.PackPath);
            using (var book = new WorkbookReader(plan.WorkbookPath))
            using (var pack = new ZipArchive(File.OpenRead(plan.PackPath), ZipArchiveMode.Read)) {
                var manifest = WorkbookReader.ReadXml(pack.GetEntry("manifest.xml")).Root;
                if (manifest.Name != "sources" || Attribute(manifest, "version") != "2") throw new IOException("原本データの形式が異なります。");
                var instructions = book.Read("作業指示");
                if (!instructions.ContainsKey(10) || WorkbookReader.Get(instructions[10], 2).Formula || WorkbookReader.Get(instructions[10], 2).Value != Attribute(manifest, "id")) throw new IOException("Excelと原本データの組み合わせが違います。");
                var sources = manifest.Elements("file").ToDictionary(e => Attribute(e, "sheet"));
                var rows = book.Read("修正案");
                if (!rows.ContainsKey(4) || WorkbookWorkflow.Headers.Where((h,i) => WorkbookReader.Get(rows[4], i+1).Value != h).Any()) throw new IOException("修正案の見出しが変更されています。");
                foreach (var row in rows.Where(r => r.Key >= 5)) {
                    var cells = Enumerable.Range(1, 6).Select(c => WorkbookReader.Get(row.Value, c)).ToArray();
                    if (cells.All(c => c.Value == "" && !c.Formula)) continue;
                    string prefix = "修正案 " + row.Key + "行目: ";
                    if (cells.Any(c => c.Formula || c.Type == "e")) throw new IOException(prefix + "数式・Excelエラーは使用できません。文字列または数値で記入してください。");
                    string sheet = cells[0].Value;
                    if (!sources.ContainsKey(sheet)) throw new IOException(prefix + "対象シートが原本データにありません。");
                    int start, end, count;
                    if (!int.TryParse(cells[1].Value, out start) || !int.TryParse(cells[2].Value, out end) || !int.TryParse(cells[4].Value, out count) || start < 1 || end < start - 1 || count < 0) throw new IOException(prefix + "開始行・終了行・置換後行数が不正です。");
                    if (string.IsNullOrWhiteSpace(cells[5].Value)) throw new IOException(prefix + "変更理由を記入してください。");
                    if (cells[3].Value.Length > 32767 || cells[3].Value.TrimStart().StartsWith("```")) throw new IOException(prefix + "コードが長すぎるか、Markdownの囲みが含まれています。");
                    if (cells[3].Value.Length > 0 && cells[3].Type != "s" && cells[3].Type != "inlineStr" && cells[3].Type != "str") throw new IOException(prefix + "置換コードは文字列として入力してください（数値への自動変換を防ぐため）。");
                    var replacement = count == 0 && cells[3].Value == "" ? new string[0] : Regex.Split(cells[3].Value, "\r\n|\r|\n");
                    if (replacement.Length != count) throw new IOException(prefix + "置換後行数がコードと一致しません。実際は " + replacement.Length + "行です。");
                    XmlConvert.VerifyXmlChars(cells[3].Value);
                    var change = plan.Files.FirstOrDefault(f => f.Sheet == sheet);
                    if (change == null) {
                        var source = sources[sheet]; string entryName = Attribute(source, "entry"); var entry = pack.GetEntry(entryName);
                        if (entry == null || entry.Length > 5 * 1024 * 1024) throw new IOException("原本データがないか大きすぎます: " + sheet);
                        byte[] bytes; using (var s = entry.Open()) using (var m = new MemoryStream()) { s.CopyTo(m); bytes = m.ToArray(); }
                        string expected = Attribute(source, "sha256"); if (Hash(bytes) != expected) throw new IOException("原本データのハッシュが一致しません: " + sheet);
                        string label = Attribute(source, "encoding"), decodedLabel;
                        string original = Importer.Decode(bytes, label.StartsWith("CP932") ? "CP932" : "UTF-8", out decodedLabel);
                        change = new FileChange { Sheet = sheet, SourcePath = Attribute(source, "path"), RelativePath = Attribute(source, "relative"), OriginalHash = expected, EncodingName = label, Original = original, Bytes = bytes };
                        ValidateRelative(change.RelativePath);
                        // Reject edits to displayed originals, even though exports use the separate baseline.
                        var sourceRows = book.Read(sheet); var originalLines = Lines(original);
                        for (int i = 0; i < originalLines.Length; i++) {
                            Dictionary<int, SheetCell> line;
                            if (!sourceRows.TryGetValue(i + 5, out line) || WorkbookReader.Get(line, 1).Value != (i + 1).ToString() || WorkbookReader.Get(line, 2).Value != originalLines[i] || WorkbookReader.Get(line, 1).Formula || WorkbookReader.Get(line, 2).Formula) throw new IOException("元コードのシートが変更されています: " + sheet + "。再取り込みして修正案だけを編集してください。");
                        }
                        if (sourceRows.Where(r => r.Key >= originalLines.Length + 5).Any(r => r.Value.Values.Any(c => c.Value != "" || c.Formula))) throw new IOException("元コードに行が追加されています: " + sheet);
                        plan.Files.Add(change);
                    }
                    if (start > Lines(change.Original).Length + 1 || end > Lines(change.Original).Length) throw new IOException(prefix + "元コードの行数を超えています。");
                    change.Edits.Add(new EditBlock { Row = row.Key, Start = start, End = end, Replacement = replacement, Reason = cells[5].Value });
                }
                if (plan.Files.Count == 0) throw new IOException("修正案がありません。Copilotで修正案シートの5行目以降を記入して保存してください。");
                foreach (var change in plan.Files) {
                    change.Edits.Sort((a,b) => a.Start.CompareTo(b.Start));
                    for (int i = 1; i < change.Edits.Count; i++) if (change.Edits[i].Start <= Math.Max(change.Edits[i-1].End, change.Edits[i-1].Start)) throw new IOException("修正範囲が重複しています: " + change.Sheet);
                    var delimiters = Regex.Matches(change.Original, "\r\n|\r|\n").Cast<Match>().Select(m => m.Value).Distinct().ToArray();
                    if (delimiters.Length > 1) throw new IOException("改行形式が混在しています。書き出しは未対応です: " + change.Sheet);
                    string newline = delimiters.Length == 0 ? "\r\n" : delimiters[0];
                    var lines = Lines(change.Original).ToList();
                    foreach (var edit in change.Edits.AsEnumerable().Reverse()) { lines.RemoveRange(edit.Start-1, edit.End-edit.Start+1); lines.InsertRange(edit.Start-1, edit.Replacement); }
                    change.Revised = string.Join(newline, lines);
                    try { change.Bytes = Encode(change.Revised, change.Bytes, change.EncodingName); }
                    catch (EncoderFallbackException) { throw new IOException("元の文字コードで表現できない文字があります: " + change.Sheet); }
                }
            }
            plan.ValidateCurrent(plan.Files);
            return plan;
        }
        public void ValidateCurrent(IEnumerable<FileChange> selected) {
            if (FileHash(WorkbookPath) != workbookHash || FileHash(PackPath) != packHash) throw new IOException("確認中にExcelまたは原本データが更新されました。修正案を開き直してください。");
            foreach (var file in selected) {
                if (!File.Exists(file.SourcePath) || FileHash(file.SourcePath) != file.OriginalHash) throw new IOException("元ファイルが更新・移動されています。再取り込みしてください: " + file.SourcePath);
            }
        }
        public string Export(string parent, IEnumerable<FileChange> selection) {
            var chosen = selection.ToList();
            if (chosen.Count == 0) throw new IOException("保存するファイルにチェックを入れてください。");
            if (chosen.Any(c => !Files.Contains(c))) throw new IOException("確認対象外の修正です。");
            ValidateCurrent(chosen);
            parent = Path.GetFullPath(parent);
            if (!Directory.Exists(parent)) throw new DirectoryNotFoundException(parent);
            string token = DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 6);
            string final = Path.Combine(parent, "修正版_" + token), staging = Path.Combine(parent, ".作成中_" + token);
            if (Directory.Exists(staging) || Directory.Exists(final)) throw new IOException("保存先が重複しました。再実行してください。");
            Directory.CreateDirectory(staging);
            try {
                var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                var readme = new StringBuilder("# Excel Copilot 修正版\r\n\r\n元ソースは変更していません。ビルド・動作検証は未実施です。\r\n\r\n");
                foreach (var file in chosen) {
                    ValidateRelative(file.RelativePath);
                    string target = Path.GetFullPath(Path.Combine(staging, file.RelativePath.Replace('/', Path.DirectorySeparatorChar)));
                    if (!target.StartsWith(staging + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || !paths.Add(target)) throw new IOException("保存先が不正または重複しています。");
                    Directory.CreateDirectory(Path.GetDirectoryName(target));
                    using (var stream = new FileStream(target, FileMode.CreateNew)) stream.Write(file.Bytes, 0, file.Bytes.Length);
                    readme.AppendLine("## " + file.RelativePath).AppendLine("元ファイル: " + file.SourcePath).AppendLine("元SHA-256: " + file.OriginalHash).AppendLine("修正SHA-256: " + Hash(file.Bytes));
                    foreach (var edit in file.Edits) readme.AppendLine("- " + edit.Start + "～" + edit.End + "行: " + edit.Reason);
                    readme.AppendLine();
                }
                File.WriteAllText(Path.Combine(staging, "README.md"), readme.ToString(), new UTF8Encoding(false));
                ValidateCurrent(chosen);
                Directory.Move(staging, final);
                return final;
            } finally {
                // Only this newly created, verified child directory can be cleaned up.
                if (Directory.Exists(staging) && Path.GetFullPath(staging).StartsWith(parent.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) Directory.Delete(staging, true);
            }
        }
    }
}
