using System;
using System.IO;
using System.Linq;
using SourceExcelImporter;
class BehaviorChecks {
    static void Main(string[] args) {
        string root = Path.GetFullPath(args[0]); Directory.CreateDirectory(root);
        string input = Path.Combine(root, "input"); Directory.CreateDirectory(input);
        Directory.CreateDirectory(Path.Combine(input, "nested"));
        File.WriteAllText(Path.Combine(input, "one.txt"), "_x0041_\n日本語\n");
        File.WriteAllText(Path.Combine(input, "two.vb"), "Dim x = 1");
        File.WriteAllText(Path.Combine(input, "nested", "three.txt"), "nested");
        var o = new Options { Output = Path.Combine(root, "filter.xlsx"), Keyword = "one", Extensions = "txt" };
        o.Folders.Add(input);
        string result = Importer.Run(o, (n,s) => {}, () => false);
        if (!result.Contains("取込済: 1件")) throw new Exception(result);
        o.Output = Path.Combine(root, "flat.xlsx"); o.Keyword = ""; o.Recursive = false;
        result = Importer.Run(o, (n,s) => {}, () => false);
        if (!result.Contains("取込済: 1件")) throw new Exception(result);
        o.Output = Path.Combine(root, "cancel.xlsx");
        bool cancel = false;
        try { Importer.Run(o, (n,s) => { if (s.StartsWith("読み込み")) cancel = true; }, () => cancel); throw new Exception("Cancellation did not occur"); }
        catch (OperationCanceledException) {}
        if (File.Exists(o.Output) || Directory.GetFiles(root, "*.tmp").Any()) throw new Exception("Cancellation left output");
        o.Output = Path.Combine(root, "empty.xlsx"); o.Keyword = "not-found";
        result = Importer.Run(o, (n,s) => {}, () => false);
        if (!result.Contains("取込済: 0件")) throw new Exception(result);
        Console.WriteLine("PASS: keyword, extension, non-recursive, cancellation cleanup, zero matches");
    }
}
