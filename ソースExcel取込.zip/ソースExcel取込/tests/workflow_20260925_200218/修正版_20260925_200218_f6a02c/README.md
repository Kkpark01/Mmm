# Excel Copilot 修正版

元ソースは変更していません。ビルド・動作検証は未実施です。

## 01_Web/main.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\workflow_20260925_200218\Web\main.java
元SHA-256: 7f61b61e6cde255f1cb3c0fd199e3ac35060624e70c5870e88b4965950b0ca88
修正SHA-256: ee3fffbd0cf01262b49f607efb761e04d88395497c145bc36c6a7728cd1484cf
- 2～2行: VBの処理に合わせる

## 01_Web/日本語.vb
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\workflow_20260925_200218\Web\日本語.vb
元SHA-256: 0ca4a0c3e7c7c16cae35e4a74dfb4bfd5876b3b29329a0e3ff41ad0bb220cb11
修正SHA-256: c8ea8f0be7ed7d379366fbe73aae9d259991e11b21b5a94bf6e32a4a6f5aaadf
- 2～2行: 文字コード検証

## 01_Web/bom.txt
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\workflow_20260925_200218\Web\bom.txt
元SHA-256: 9fe311b895f3b1277c11a1e28d77e3aa9db57129745c03831c244cb9ee11986c
修正SHA-256: dd50d0eadab93201db98f9137264bab5addc99c3c5848b4d1042e188658c67cc
- 2～2行: 文字列とBOM

## 01_Web/utf16.txt
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\workflow_20260925_200218\Web\utf16.txt
元SHA-256: e307dae88141a5cd95b7961b99c8c893d71770682cbf2e6b568b46923c436d77
修正SHA-256: 9a785da943ee07ed73745321619059dba25ded3c569fc8c23754c981c28c2fbf
- 2～2行: UTF16検証

## 01_Web/empty.txt
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\workflow_20260925_200218\Web\empty.txt
元SHA-256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
修正SHA-256: d91017c932b5fc756522e43c732b39b893d8061e3045e7f942ae7ebbf5bfb043
- 1～0行: 空ファイルへの挿入

