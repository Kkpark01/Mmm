class A {
  int n = 2;
}
