from pathlib import Path
import subprocess
import time
import shutil
import zipfile
import xml.etree.ElementTree as ET
import openpyxl

app = Path(__file__).resolve().parents[1]
run = app / 'tests' / ('workflow_' + time.strftime('%Y%m%d_%H%M%S'))
src = run / 'Web'
src.mkdir(parents=True)
originals = {
    'main.java': 'class A {\r\n  int n = 1;\r\n}\r\n'.encode('utf-8'),
    '日本語.vb': "'日本語\r\nDim n = 1\r\n".encode('cp932'),
    'bom.txt': '日本語\nnext\n'.encode('utf-8-sig'),
    'utf16.txt': '日本語\r\nnext\r\n'.encode('utf-16'),
    'empty.txt': b'',
    'mixed.txt': b'first\r\nsecond\n',
}
for name, data in originals.items():
    (src / name).write_bytes(data)
original = run / 'original.xlsx'
assert subprocess.run([str(app / 'SourceExcelImporter.exe'), '--import', str(original), str(src)], timeout=30).returncode == 0
base = openpyxl.load_workbook(original)
sheets = {Path(row[2]).name: row[1] for row in list(base['ファイル一覧'].values)[4:] if row[0] == '取込済'}

def create(name, edits, mutate=None):
    book = openpyxl.load_workbook(original)
    for i, edit in enumerate(edits, 5):
        for j, value in enumerate(edit, 1):
            c = book['修正案'].cell(i, j, value)
            if j == 4:
                c.data_type = 's'  # Copilot must store code literally, including leading '='.
    if mutate:
        mutate(book)
    path = run / (name + '.xlsx')
    book.save(path)
    shutil.copyfile(str(original) + '.sources.zip', str(path) + '.sources.zip')
    return path

def probe(path, ok, mode=None):
    result = subprocess.run([str(app / 'WorkflowProbe.exe'), str(path), str(run)] + ([mode] if mode else []), capture_output=True, timeout=30)
    assert result.returncode == (0 if ok else 1), (path.name, result.stdout, result.stderr)
    assert not list(run.glob('.作成中_*'))
    return result

main = sheets['main.java']
valid = create('valid', [
    [main, 2, 2, '  int n = 2;\n  int m = 3;', 2, 'VBの処理に合わせる'],
    [sheets['日本語.vb'], 2, 2, 'Dim n = 2', 1, '文字コード検証'],
    [sheets['bom.txt'], 2, 2, '=text', 1, '文字列とBOM'],
    [sheets['utf16.txt'], 2, 2, '変更', 1, 'UTF16検証'],
    [sheets['empty.txt'], 1, 0, '追加', 1, '空ファイルへの挿入'],
])
probe(valid, True)
dest = sorted(run.glob('修正版_*'))[-1]
assert (dest / '01_Web/main.java').read_bytes() == b'class A {\r\n  int n = 2;\r\n  int m = 3;\r\n}\r\n'
assert (dest / '01_Web/日本語.vb').read_bytes() == "'日本語\r\nDim n = 2\r\n".encode('cp932')
assert (dest / '01_Web/bom.txt').read_bytes() == '日本語\n=text\n'.encode('utf-8-sig')
assert (dest / '01_Web/utf16.txt').read_bytes() == '日本語\r\n変更\r\n'.encode('utf-16')
assert (dest / '01_Web/empty.txt').read_bytes() == '追加'.encode('utf-8')
assert (dest / 'README.md').exists()
for name, data in originals.items():
    assert (src / name).read_bytes() == data
before = set(run.glob('修正版_*'))
probe(valid, True, 'first')
selected = (set(run.glob('修正版_*')) - before).pop()
assert sorted(p.name for p in selected.rglob('*') if p.is_file()) == ['README.md', 'main.java']

valid_edit = [main, 2, 2, '  int n = 2;', 1, '理由']
cases = [
    ('overlap', [valid_edit, valid_edit]),
    ('missing_count', [[main, 2, 2, 'x', None, '理由']]),
    ('wrong_count', [[main, 2, 2, 'x\ny', 1, '理由']]),
    ('out_of_range', [[main, 999, 999, 'x', 1, '理由']]),
    ('unknown', [['missing', 1, 1, 'x', 1, '理由']]),
    ('empty', []),
    ('fence', [[main, 2, 2, '```java\nx\n```', 3, '理由']]),
    ('encoding', [[sheets['日本語.vb'], 2, 2, '😀', 1, '理由']]),
    ('mixed_newlines', [[sheets['mixed.txt'], 1, 1, 'x', 1, '理由']]),
    ('no_reason', [[main, 2, 2, 'x', 1, '']]),
]
for name, edits in cases:
    probe(create(name, edits), False)
probe(create('formula', [valid_edit], lambda b: setattr(b['修正案']['B5'], 'value', '=1+1')), False)
probe(create('numeric_code', [valid_edit], lambda b: setattr(b['修正案']['D5'], 'value', 123)), False)
probe(create('changed_original', [valid_edit], lambda b: setattr(b[main]['B6'], 'value', 'tampered')), False)
probe(create('wrong_pair', [valid_edit], lambda b: setattr(b['作業指示']['B10'], 'value', 'wrong')), False)
probe(valid, False, 'stale')
probe(valid, False, 'workbook-stale')
delete = create('delete', [[main, 2, 2, '', 0, '行を削除']])
before = set(run.glob('修正版_*'))
probe(delete, True)
deleted = (set(run.glob('修正版_*')) - before).pop()
assert (deleted / '01_Web/main.java').read_bytes() == b'class A {\r\n}\r\n'
insert = create('insert', [[main, 2, 1, '  // added', 1, '行を挿入']])
before = set(run.glob('修正版_*'))
probe(insert, True)
inserted = (set(run.glob('修正版_*')) - before).pop()
assert (inserted / '01_Web/main.java').read_bytes() == b'class A {\r\n  // added\r\n  int n = 1;\r\n}\r\n'

# Simulate Excel's shared string storage and worksheet relationship names.
shared = create('shared_strings', [valid_edit])
ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
with zipfile.ZipFile(shared) as z:
    entries = {n: z.read(n) for n in z.namelist()}
xml = ET.fromstring(entries['xl/worksheets/sheet3.xml'])
sst = ET.Element('{' + ns + '}sst')
for cell in xml.iter('{' + ns + '}c'):
    if cell.get('t') == 'inlineStr':
        node = cell.find('{' + ns + '}is')
        item = ET.SubElement(sst, '{' + ns + '}si')
        if node is not None:
            for element in list(node):
                item.append(element)
            cell.remove(node)
        cell.set('t', 's')
        ET.SubElement(cell, '{' + ns + '}v').text = str(len(sst) - 1)
entries['xl/worksheets/sheet3.xml'] = ET.tostring(xml)
entries['xl/sharedStrings.xml'] = ET.tostring(sst)
with zipfile.ZipFile(shared, 'w') as z:
    for name, data in entries.items():
        z.writestr(name, data)
probe(shared, True)

# A malicious relative path in a modified baseline must never escape the output.
traversal = create('traversal', [valid_edit])
packpath = Path(str(traversal) + '.sources.zip')
with zipfile.ZipFile(packpath) as z:
    entries = {n: z.read(n) for n in z.namelist()}
manifest = ET.fromstring(entries['manifest.xml'])
next(f for f in manifest if f.get('sheet') == main).set('relative', '../escaped.java')
entries['manifest.xml'] = ET.tostring(manifest)
with zipfile.ZipFile(packpath, 'w') as z:
    for name, data in entries.items():
        z.writestr(name, data)
probe(traversal, False)
assert not (run / 'escaped.java').exists()
assert subprocess.run([str(app / 'SourceExcelImporter.exe'), '--preview-review', str(valid), str(run / 'review.png')], timeout=30).returncode == 0
print('PASS: replacement, insert, delete, selected export, encodings/BOM/EOL, hashes, originals preserved, stale source/workbook, malformed edits, formulas, path traversal, shared strings, review rendering')
print(run)
