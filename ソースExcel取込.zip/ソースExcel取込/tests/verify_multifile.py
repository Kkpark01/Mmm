"""Independent end-to-end checks for multiple files and multiple edits per file."""
from pathlib import Path
import subprocess
import time
import shutil
import random
import json
import openpyxl

app = Path(__file__).resolve().parents[1]
run = app / 'tests' / ('multifile_' + time.strftime('%Y%m%d_%H%M%S'))
roots = [run / 'projectA' / 'Web', run / 'projectB' / 'Web']
originals, expected = {}, {}
for root_no, root in enumerate(roots, 1):
    for n in range(12):
        file = root / ('area' + str(n // 3)) / ('File' + str(n % 3) + '.java')
        file.parent.mkdir(parents=True, exist_ok=True)
        lines = [f'  root={root_no} file={n} line={i} 日本語' for i in range(1, 21)] + ['']
        newline = '\r\n' if n % 2 == 0 else '\n'
        encoding = ('utf-8', 'utf-8-sig', 'cp932', 'utf-16')[n % 4]
        original = newline.join(lines).encode(encoding)
        file.write_bytes(original)
        originals[file] = original
        # Construct expected output independently, using original slices in forward order.
        revised = lines[:1] + ['  replaced A', '  replaced B'] + lines[2:4] + lines[5:7] + ['  inserted'] + lines[7:9] + ['  combined'] + lines[11:14] + ['=literal'] + lines[15:20] + ['  appended', '']
        relative = f'{root_no:02d}_Web/' + file.relative_to(root).as_posix()
        expected[relative] = newline.join(revised).encode(encoding)

original = run / 'original.xlsx'
exe = app / 'SourceExcelImporter.exe'
assert subprocess.run([str(exe), '--import', str(original)] + [str(r) for r in roots], timeout=60).returncode == 0
base = openpyxl.load_workbook(original)
records = [r for r in list(base['ファイル一覧'].values)[4:] if r[0] == '取込済']
assert len(records) == 24
edits = []
for record in records:
    sheet = record[1]
    edits.extend([
        [sheet, 2, 2, '  replaced A\n  replaced B', 2, '複数行への置換'],
        [sheet, 5, 5, '', 0, '削除'],
        [sheet, 8, 7, '  inserted', 1, '途中へ挿入'],
        [sheet, 10, 11, '  combined', 1, '複数行をまとめる'],
        [sheet, 15, 15, '=literal', 1, '数式に見える文字列'],
        [sheet, 21, 20, '  appended', 1, '末尾改行の前へ追加'],
    ])
random.Random(20260925).shuffle(edits)

def workbook(name, rows):
    book = openpyxl.load_workbook(original)
    for row, values in enumerate(rows, 5):
        for column, value in enumerate(values, 1):
            cell = book['修正案'].cell(row, column, value)
            if column == 4:
                cell.data_type = 's'
    file = run / (name + '.xlsx')
    book.save(file)
    shutil.copyfile(str(original) + '.sources.zip', str(file) + '.sources.zip')
    return file

def invoke(file, success, mode=None):
    before = set(run.glob('修正版_*'))
    result = subprocess.run([str(app / 'WorkflowProbe.exe'), str(file), str(run)] + ([mode] if mode else []), capture_output=True, timeout=60)
    assert result.returncode == (0 if success else 1), (result.stdout, result.stderr)
    after = set(run.glob('修正版_*'))
    assert not list(run.glob('.作成中_*')), 'Partial output left behind'
    if success:
        assert len(after - before) == 1
        return (after - before).pop()
    assert after == before, 'Failed operation published a partial result'

valid = workbook('valid', edits)
dest = invoke(valid, True)
actual = {p.relative_to(dest).as_posix(): p.read_bytes() for p in dest.rglob('*.java')}
assert actual == expected, 'Output bytes/path did not match expected content'
assert len(actual) == 24
# A second export must create another full result and preserve the previous result.
second = invoke(valid, True)
assert second != dest
assert {p.relative_to(dest).as_posix(): p.read_bytes() for p in dest.rglob('*.java')} == expected
assert {p.relative_to(second).as_posix(): p.read_bytes() for p in second.rglob('*.java')} == expected
# Selected-file export includes all edits for that file, not edits from other files.
selected = invoke(valid, True, 'first')
selected_files = list(selected.rglob('*.java'))
assert len(selected_files) == 1
assert selected_files[0].read_bytes() == expected[selected_files[0].relative_to(selected).as_posix()]
# Fail after a first file has been staged; no partial final output may be published.
invoke(valid, False, 'write-failure')
invoke(valid, False, 'duplicate-target')
# One invalid edit among otherwise valid multi-file edits must block the whole export.
invoke(workbook('one_bad_count', edits + [[records[-1][1], 19, 19, 'x\ny', 1, '不正な行数']]), False)
invoke(workbook('one_overlap', edits + [[records[-1][1], 10, 10, 'x', 1, '範囲重複']]), False)
changed = Path(records[-1][2])
try:
    changed.write_bytes(originals[changed] + b'changed')
    invoke(valid, False)
finally:
    changed.write_bytes(originals[changed])
for file, data in originals.items():
    assert file.read_bytes() == data, f'Original was modified: {file}'
report = {
    'result': 'PASS', 'files': 24, 'edits': 144, 'roots_with_same_name': 2,
    'checks': ['same-name files in different roots and subfolders', 'random edit order',
               'six edits per file', 'insert/delete/replace with changing line counts',
               'four encodings and CRLF/LF byte comparison', 'selected export',
               'repeat export preserves previous outputs', 'failure after first staged file',
               'duplicate output path rollback', 'one invalid file rejects all',
               'one stale source rejects all', 'all original bytes preserved'],
}
(run / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=True))
print(run)
