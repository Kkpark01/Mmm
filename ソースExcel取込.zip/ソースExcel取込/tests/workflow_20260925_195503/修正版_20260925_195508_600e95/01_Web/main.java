class A {
  // added
  int n = 1;
}
