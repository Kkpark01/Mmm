class A {
  int n = 1;
}
