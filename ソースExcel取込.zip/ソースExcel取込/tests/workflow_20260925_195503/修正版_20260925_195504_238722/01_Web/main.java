class A {
  int n = 2;
  int m = 3;
}
