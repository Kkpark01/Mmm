import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const require = createRequire('C:/Users/teras/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/runtime.cjs');
const { FileBlob, SpreadsheetFile } = await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
const file = process.argv[2];
const book = await SpreadsheetFile.importXlsx(await FileBlob.load(file));
for (const [name, range, output] of [['作業指示','A1:B12','instructions.png'], ['修正案','A1:F6','edits.png']]) {
  const image = await book.render({ sheetName: name, range, scale: 1.4 });
  await fs.writeFile(path.join(path.dirname(file), output), new Uint8Array(await image.arrayBuffer()));
}
console.log('Rendered instruction and edit sheets.');
