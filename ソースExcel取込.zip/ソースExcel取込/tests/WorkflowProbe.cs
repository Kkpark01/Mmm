using System;
using System.IO;
using System.Linq;
using SourceExcelImporter;
class WorkflowProbe {
    static int Main(string[] args) {
        try {
            var plan = ChangePlan.Load(args[0]);
            if (args.Length > 2 && args[2] == "write-failure") {
                // Force a file/directory collision after the first file has been written.
                plan.Files[1].RelativePath = plan.Files[0].RelativePath + "/child.txt";
                plan.Export(args[1], plan.Files);
                return 0;
            }
            if (args.Length > 2 && args[2] == "duplicate-target") {
                plan.Files[1].RelativePath = plan.Files[0].RelativePath;
                plan.Export(args[1], plan.Files);
                return 0;
            }
            if (args.Length > 2 && args[2] == "stale") {
                string path = plan.Files[0].SourcePath;
                byte[] bytes = File.ReadAllBytes(path);
                try { File.AppendAllText(path, "changed"); plan.Export(args[1], plan.Files); }
                finally { File.WriteAllBytes(path, bytes); }
            } else if (args.Length > 2 && args[2] == "workbook-stale") {
                byte[] bytes = File.ReadAllBytes(args[0]);
                try { File.AppendAllText(args[0], "changed"); plan.Export(args[1], plan.Files); }
                finally { File.WriteAllBytes(args[0], bytes); }
            } else {
                Console.WriteLine(plan.Export(args[1], args.Length > 2 && args[2] == "first" ? plan.Files.Take(1) : plan.Files));
            }
            return 0;
        } catch (Exception ex) { Console.WriteLine(ex.Message); return 1; }
    }
}
