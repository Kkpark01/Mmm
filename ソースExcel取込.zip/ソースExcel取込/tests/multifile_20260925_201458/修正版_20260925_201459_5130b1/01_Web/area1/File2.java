﻿  root=1 file=5 line=1 日本語
  replaced A
  replaced B
  root=1 file=5 line=3 日本語
  root=1 file=5 line=4 日本語
  root=1 file=5 line=6 日本語
  root=1 file=5 line=7 日本語
  inserted
  root=1 file=5 line=8 日本語
  root=1 file=5 line=9 日本語
  combined
  root=1 file=5 line=12 日本語
  root=1 file=5 line=13 日本語
  root=1 file=5 line=14 日本語
=literal
  root=1 file=5 line=16 日本語
  root=1 file=5 line=17 日本語
  root=1 file=5 line=18 日本語
  root=1 file=5 line=19 日本語
  root=1 file=5 line=20 日本語
  appended
