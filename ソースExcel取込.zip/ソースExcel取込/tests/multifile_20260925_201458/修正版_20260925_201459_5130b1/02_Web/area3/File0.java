﻿  root=2 file=9 line=1 日本語
  replaced A
  replaced B
  root=2 file=9 line=3 日本語
  root=2 file=9 line=4 日本語
  root=2 file=9 line=6 日本語
  root=2 file=9 line=7 日本語
  inserted
  root=2 file=9 line=8 日本語
  root=2 file=9 line=9 日本語
  combined
  root=2 file=9 line=12 日本語
  root=2 file=9 line=13 日本語
  root=2 file=9 line=14 日本語
=literal
  root=2 file=9 line=16 日本語
  root=2 file=9 line=17 日本語
  root=2 file=9 line=18 日本語
  root=2 file=9 line=19 日本語
  root=2 file=9 line=20 日本語
  appended
