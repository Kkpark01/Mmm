# Excel Copilot 修正版

元ソースは変更していません。ビルド・動作検証は未実施です。

## 02_Web/area2/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area2\File2.java
元SHA-256: 6842436ed20a1aee5b24f2ffa4501652ed9831f286c3c7f9de586f4b07ab6d67
修正SHA-256: 021d1be60fbdd8a1a5a78c5502418e14d834a305964ccba2e99ed0f092b23066
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area1/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area1\File1.java
元SHA-256: cd3c957c17af42548e64325cb7f817764597f0351f81f305520d5c6766815455
修正SHA-256: a36bb42c7bf1dc0ac5926bcf8be161d643978eef2e4b698548b00e0acc96249d
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area0/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area0\File2.java
元SHA-256: fe1987e7aedb8ca7769a2bb2c314b9b69df3fcdb2b39d1af7ffb1c301ae39432
修正SHA-256: 09157eb8ecfd7add590fb3c6981fd5a408690179b4b5cb44515d26f88ab2c933
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area3/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area3\File2.java
元SHA-256: 8b91950b1771718a22b33a413346b2820ac31028aa7ef07ec943a6e5fbb74e71
修正SHA-256: 6d5626b4a52af502a1faba898428994aae7121125292751eec9dc2775ec43c49
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area2/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area2\File2.java
元SHA-256: 28c14ad2fee296c2e09db4f7283c9b631bdc4b74cb742539f7ef70818afc72e0
修正SHA-256: 411fa79ecee4dedaa14f8d4e04e3ffbc89d5b48cf6e0cff1f548d9cc4a3d09e1
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area0/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area0\File1.java
元SHA-256: d0790fc3175275aa444813c046d95d70ca15facdc33866b146dae237d1a5a56c
修正SHA-256: 544a53c522fee6775f301742faf36de103ce6d1968e43ccfa18bcc6070051ea4
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area1/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area1\File0.java
元SHA-256: aa255337937cc12dd759620adbe4137c50bd27c3ec856d4e3d64e2a6815b7db6
修正SHA-256: bc7d6c54ff618a7ab259fffb0476c716ada7171c4555711de98567d1b2f7b3e8
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area2/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area2\File1.java
元SHA-256: 4941c6aaec95bd66d2219c7fd49cd9963554ccee7dfc8ca8bafb29e2db44d0d3
修正SHA-256: 0d09422ad268b8d4551921f053a72eba561d14005c073902fb2ee0480432a5df
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area3/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area3\File0.java
元SHA-256: fb33878271ce9af71c7d107d3e289abf850c4be60ac9d9b279ec125268a1a461
修正SHA-256: 66edd7c08cfe838462d3928cd03e904a5b1113b581294b772bc646d1179897e6
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area0/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area0\File0.java
元SHA-256: 8ad915abe035430eb232e8e41d14ca9b28b9886d6d7f09ea61f0212cc829803d
修正SHA-256: ddcbc32a4f3f5e5c5322a918ad6021f78708a4962f9f4e0eed049c1bfbcc873f
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area1/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area1\File2.java
元SHA-256: aca8b766721683842bae284c38ac28dbee43ed6f96b7c616bf40d42244d838b5
修正SHA-256: 5ab2ac654c8d7bad23841e5d04f64753a68efe9238ceae850b82f017d7fd65fa
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area2/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area2\File1.java
元SHA-256: 682f44267dfbc942ca7ad004bed1eaeba48155e96f0e8cfc1b891518a1d86644
修正SHA-256: 341c7ba824569bfac6e5aa894ac338749792d6139086d488ad3a74dfd85990c4
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area3/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area3\File0.java
元SHA-256: dc9706bab9b6d86f15c2efb0c68ac0a69ebb875cc1a62b771682d5d285a39f0e
修正SHA-256: 009776b875be06e35cddae10753f0511a2e7ef2a35fcd8787e82c37f878f2c8b
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area2/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area2\File0.java
元SHA-256: 58eba10c8247e17b1e6a15dce9d692964770e7c7504d32190235917e788f589a
修正SHA-256: 51fd22b6bd4bba84d1dbef1b3b952197467d66ae329aae575af0f21b7ae24765
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area0/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area0\File2.java
元SHA-256: 9e14587171a767e79dd1ffd91a3cbd7948e5871ad8f43246fcfb542b2bf10c47
修正SHA-256: 734f558c5c97aec21fd0cd8937c5c35fb9bee51a43c8354d7462098ec5dd855f
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area2/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area2\File0.java
元SHA-256: dd88d3e0a1d07d07c20787c1302b1a86ff2815e38224e8690838e75af9e2a88c
修正SHA-256: 291afbb4b1ad2b6ff5972a129b460b1bbcddf3218f3d04fa14732e3f52298562
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area0/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area0\File1.java
元SHA-256: 30a4b186aec1d33c29c668832abddb76d656009835050bdd95adeb16c8f8a919
修正SHA-256: e7b8940e0ca8114086e13e6feb8a6749f0606b9fd2fd304c6fb7036faa73b211
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area1/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area1\File2.java
元SHA-256: 382521c09f9d00bbe2fa0be1eb16409ef0969dafd2320caf87d37f5ebaa93a3a
修正SHA-256: bf83cc7bfd9d39a45b7852bb55b453cbe548841fd66649eb5f001db771a4e318
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area3/File2.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area3\File2.java
元SHA-256: f872b59b6cf8d230c8e25f16bbc83d4bdb899a9be558f2340dabd0409bc5b882
修正SHA-256: 221e034c5e3f12806922d488472b685fcc9d7371f39b587ae6525df4e7c05401
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area3/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area3\File1.java
元SHA-256: fcc3d42bf93ceb869c165ddbd6e2b570d3b95c11b08f00c1c674d7e7dcbe6c89
修正SHA-256: ccf96649bb5435107bdf0e8c9feab52cb7da7dbbd99de9c290a6d4a86772fa6a
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area1/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area1\File0.java
元SHA-256: 887d901fa4a7c8b0880410cf1d7ca4fc495188dc727ce9dc9a01d404176f6df7
修正SHA-256: 99d54390975249e5da54c33149a69c7471f0c7b1d8ac9a96b7760220875a7fcf
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area1/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area1\File1.java
元SHA-256: 9ac7e8829c3917dbcd54002f0ec4272a5e05c6e447cae9d27c82c45a67d78fbe
修正SHA-256: 734e89c146ebfd2d8c0f51d93d572b0a256dcf45a8dd7e5565882e93f2d67ca6
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 01_Web/area3/File1.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectA\Web\area3\File1.java
元SHA-256: 5b2efb5f42b742d4cc29d5cac257d5cd533cbdd287a04423c267027023e53419
修正SHA-256: 9ba63690af5369012ac49dcf0c208100f57b6a8f69f7a69612332c4fe4cbccbe
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

## 02_Web/area0/File0.java
元ファイル: C:\Users\teras\Desktop\遠隔操作用\MCM\ツール\ソースExcel取込\tests\multifile_20260925_201458\projectB\Web\area0\File0.java
元SHA-256: 28c9e22084aa69d0d09fe26e4d60da27d818e6e50bae6a2a15772d02295752cd
修正SHA-256: 09c939e6de9e7ecbb254ea04ab20bbe134c16e43e56269d241e10933c705605c
- 2～2行: 複数行への置換
- 5～5行: 削除
- 8～7行: 途中へ挿入
- 10～11行: 複数行をまとめる
- 15～15行: 数式に見える文字列
- 21～20行: 末尾改行の前へ追加

