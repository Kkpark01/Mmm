"""Run the shipped executable and independently inspect its XLSX output."""
from pathlib import Path
import hashlib
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
import openpyxl

app = Path(__file__).resolve().parents[1]
run = app / 'tests' / ('run_' + time.strftime('%Y%m%d_%H%M%S'))
root = run / 'VB'
web = run / 'Web'
root.mkdir(parents=True)
web.mkdir()
sources = {
    root / '日本語.vb': ("'日本語\r\n  Dim x = 1\r\n\r\n", 'cp932'),
    root / '同名.txt': ('=1+1\n+SUM(A1:A2)\n@text\n0012\n\t末尾  ', 'utf-8'),
    web / '同名.txt': ('<html>&"日本語</html>\n', 'utf-8-sig'),
    web / 'utf16.txt': ('日本語\r\n次の行', 'utf-16'),
    web / '空.txt': ('', 'utf-8'),
    web / ('長い名前' * 12 + '.txt'): ('long name', 'utf-8'),
}
for path, (text, encoding) in sources.items():
    path.write_bytes(text.encode(encoding))
(web / 'bad.txt').write_bytes(b'\x81')
(web / 'binary.txt').write_bytes(b'abc\x00def')
(web / 'longline.txt').write_text('a' * 32768, encoding='utf-8')
(web / 'image.png').write_bytes(b'not imported')
(web / 'node_modules').mkdir()
(web / 'node_modules' / 'excluded.js').write_text('excluded')
exe = app / 'SourceExcelImporter.exe'
out = run / 'result.xlsx'
result = subprocess.run([str(exe), '--import', str(out), str(root), str(web), str(root)], timeout=60)
assert result.returncode == 0, list(run.glob('*.error.log'))
book = openpyxl.load_workbook(out)
assert len(book.sheetnames) == 9, book.sheetnames
assert len(set(s.lower() for s in book.sheetnames)) == 9
assert out.with_name(out.name + '.sources.zip').exists()
assert all(len(s) <= 31 for s in book.sheetnames)
rows = list(book.worksheets[0].values)[4:]
assert sum(r[0] == '取込済' for r in rows) == 6
assert sum(r[0] == 'エラー' for r in rows) == 3
assert sum(r[0] == '除外' for r in rows) == 2
import re
for record in rows:
    if record[0] != '取込済':
        continue
    path = Path(record[2])
    text, encoding = sources[path]
    sheet = book[record[1]]
    actual = [r[1] or '' for r in list(sheet.values)[4:]]
    expected = re.split(r'\r\n|\n|\r', text) if text else []
    assert actual == expected, (path, actual, expected)
    assert record[7] == hashlib.sha256(path.read_bytes()).hexdigest()
    assert sheet.freeze_panes == 'A5'
    assert all(c.data_type != 'f' for row in sheet for c in row)
with zipfile.ZipFile(out) as archive:
    for name in archive.namelist():
        if name.endswith(('.xml', '.rels')):
            ET.fromstring(archive.read(name))
before = out.read_bytes()
assert subprocess.run([str(exe), '--import', str(out), str(root)], timeout=60).returncode == 1
assert out.read_bytes() == before, 'Existing workbook was modified'
assert subprocess.run([str(exe), '--import', str(run / 'missing.xlsx'), str(run / 'missing')], timeout=60).returncode == 1
assert not (run / 'missing.xlsx').exists()
preview = run / 'app.png'
assert subprocess.run([str(exe), '--preview', str(preview)], timeout=60).returncode == 0
assert preview.exists()
print('PASS: encoding, blank lines, whitespace, literal formulas, duplicate roots/names, long names, exclusion, invalid text, long lines, hashes, XML, overwrite prevention, missing folder, UI rendering')
print(run)
